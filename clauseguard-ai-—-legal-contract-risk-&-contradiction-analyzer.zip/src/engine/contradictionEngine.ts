import { Clause, ContradictionDetail, RiskFinding, ContractRelationship } from '../types/contract';

/**
 * Calculates TF-IDF style token cosine similarity between two texts.
 */
function computeSemanticSimilarity(textA: string, textB: string): number {
  const tokenize = (str: string) =>
    str
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, ' ')
      .split(/\s+/)
      .filter(w => w.length > 2);

  const tokensA = tokenize(textA);
  const tokensB = tokenize(textB);

  const freqA = new Map<string, number>();
  const freqB = new Map<string, number>();

  for (const t of tokensA) freqA.set(t, (freqA.get(t) || 0) + 1);
  for (const t of tokensB) freqB.set(t, (freqB.get(t) || 0) + 1);

  const allWords = new Set([...freqA.keys(), ...freqB.keys()]);
  let dotProduct = 0;
  let normA = 0;
  let normB = 0;

  for (const w of allWords) {
    const a = freqA.get(w) || 0;
    const b = freqB.get(w) || 0;
    dotProduct += a * b;
    normA += a * a;
    normB += b * b;
  }

  if (normA === 0 || normB === 0) return 0;
  return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}

interface ContradictionCandidate {
  finding: RiskFinding;
  relationship: ContractRelationship;
}

/**
 * High-precision contradiction detection engine across semantic domains.
 */
export function detectContradictions(clauses: Clause[]): {
  findings: RiskFinding[];
  relationships: ContractRelationship[];
} {
  const findings: RiskFinding[] = [];
  const relationships: ContractRelationship[] = [];

  // Group clauses by primary categories for focused comparison
  const indemnityClauses = clauses.filter(c => c.category === 'Indemnity' || /indemnif|hold harmless/i.test(c.text));
  const liabilityClauses = clauses.filter(c => c.category === 'Limitation of Liability' || /liability cap|aggregate liability|shall not exceed/i.test(c.text));
  const terminationClauses = clauses.filter(c => c.category === 'Termination' || /terminate|termination|notice/i.test(c.title + ' ' + c.text));
  const ipClauses = clauses.filter(c => c.category === 'Intellectual Property' || /intellectual property|ownership|work made for hire|deliverables|patents/i.test(c.text));
  const govLawClauses = clauses.filter(c => c.category === 'Governing Law' || /governing law|laws of the state|jurisdiction/i.test(c.text));
  const disputeClauses = clauses.filter(c => c.category === 'Dispute Resolution' || /arbitration|siac|dispute resolution|tribunal|exclusive jurisdiction/i.test(c.text));
  const confidentialityClauses = clauses.filter(c => c.category === 'Confidentiality' || /confidential|non-disclosure|survival/i.test(c.text));
  const warrantyClauses = clauses.filter(c => c.category === 'Warranty' || /warranty|as is|guarantee/i.test(c.text));

  let findingCounter = 1;

  // 1. INDEMNITY VS LIABILITY CAP CONTRADICTION
  for (const ind of indemnityClauses) {
    const hasUnlimitedIndemnity =
      /without limitation|unlimited|absolute|any and all claims.*without limitation|sole and absolute/i.test(ind.text);

    for (const liab of liabilityClauses) {
      if (ind.id === liab.id) continue;

      const capMatch = liab.text.match(/\$[0-9,]+|\b[0-9,]+\s*u\.s\.\s*dollars|\bcap of\b/i);
      const includesIndemnityInCap = /whether in contract, tort.*indemnity|including indemnity|notwithstanding anything to the contrary/i.test(liab.text);
      const isCapped = /shall not exceed|aggregate liability.*limited|maximum liability/i.test(liab.text);

      if (hasUnlimitedIndemnity && (isCapped || capMatch)) {
        const capAmount = capMatch ? capMatch[0] : 'an explicit dollar threshold';
        const indSnippet = extractSnippet(ind.text, /without limitation|any and all claims/i);
        const liabSnippet = extractSnippet(liab.text, /shall not exceed|aggregate liability/i);

        const findingId = `contra-${findingCounter++}`;
        const contra: ContradictionDetail = {
          clauseAId: ind.id,
          clauseANumber: ind.clauseNumber,
          clauseATitle: ind.title,
          clauseASnippet: indSnippet,
          clauseBId: liab.id,
          clauseBNumber: liab.clauseNumber,
          clauseBTitle: liab.title,
          clauseBSnippet: liabSnippet,
          conflictDimension: 'Liability vs Indemnity',
          explanation: `${ind.clauseNumber} (${ind.title}) establishes broad, unlimited indemnity obligations without monetary ceiling, whereas ${liab.clauseNumber} (${liab.title}) imposes an aggregate liability cap of ${capAmount}${includesIndemnityInCap ? ' explicitly applying to indemnity claims' : ''}.`
        };

        findings.push({
          id: findingId,
          severity: 'Critical',
          confidence: 94,
          type: 'Contradiction',
          title: 'Direct Conflict: Unlimited Indemnity vs Aggregate Liability Cap',
          explanation: `${ind.clauseNumber} states indemnification obligations are "without limitation as to monetary liability", while ${liab.clauseNumber} limits total liability to ${capAmount}. If a major claim arises, it is legally ambiguous whether indemnity is excluded from or subject to the cap.`,
          affectedClauseNumbers: [ind.clauseNumber, liab.clauseNumber],
          affectedClauseIds: [ind.id, liab.id],
          recommendedAction: `Explicitly harmonize ${ind.clauseNumber} and ${liab.clauseNumber} by specifying whether indemnification obligations are excluded as a "super-cap" or subject to the ${capAmount} ceiling.`,
          contradiction: contra,
          evidenceQuotes: [indSnippet, liabSnippet]
        });

        relationships.push({
          id: `rel-${findingId}`,
          sourceClauseId: ind.id,
          sourceClauseNumber: ind.clauseNumber,
          sourceTitle: ind.title,
          targetClauseId: liab.id,
          targetClauseNumber: liab.clauseNumber,
          targetTitle: liab.title,
          relationshipType: 'CONTRADICTS',
          severity: 'Critical',
          description: `Unlimited indemnity directly collides with ${capAmount} liability cap`
        });
      }
    }
  }

  // 2. TERMINATION NOTICE PERIOD CONFLICT
  for (let i = 0; i < terminationClauses.length; i++) {
    for (let j = i + 1; j < terminationClauses.length; j++) {
      const cA = terminationClauses[i];
      const cB = terminationClauses[j];

      const noticeA = extractNoticeDays(cA.text);
      const noticeB = extractNoticeDays(cB.text);

      if (noticeA && noticeB && noticeA !== noticeB) {
        const isNoticeConflict =
          (/convenience|at will|prior written notice|terminate this agreement/i.test(cA.text)) &&
          (/convenience|at will|prior written notice|terminate this agreement/i.test(cB.text));

        if (isNoticeConflict) {
          const findingId = `contra-${findingCounter++}`;
          const snipA = extractSnippet(cA.text, new RegExp(`${noticeA}\\s*days`, 'i'));
          const snipB = extractSnippet(cB.text, new RegExp(`${noticeB}\\s*days`, 'i'));

          const contra: ContradictionDetail = {
            clauseAId: cA.id,
            clauseANumber: cA.clauseNumber,
            clauseATitle: cA.title,
            clauseASnippet: snipA,
            clauseBId: cB.id,
            clauseBNumber: cB.clauseNumber,
            clauseBTitle: cB.title,
            clauseBSnippet: snipB,
            conflictDimension: 'Termination Notice',
            explanation: `${cA.clauseNumber} prescribes a ${noticeA}-day notice period for termination, while ${cB.clauseNumber} mandates a ${noticeB}-day notice window.`
          };

          findings.push({
            id: findingId,
            severity: 'High',
            confidence: 91,
            type: 'Contradiction',
            title: `Conflicting Termination Notice Periods (${noticeA} Days vs ${noticeB} Days)`,
            explanation: `${cA.clauseNumber} stipulates that termination may occur upon ${noticeA} days' prior written notice, whereas ${cB.clauseNumber} requires at least ${noticeB} days' prior notice. This discrepancy risks wrongful termination claims.`,
            affectedClauseNumbers: [cA.clauseNumber, cB.clauseNumber],
            affectedClauseIds: [cA.id, cB.id],
            recommendedAction: `Standardize the notice period across both sections to a single agreed timeline (e.g. either ${noticeA} or ${noticeB} days).`,
            contradiction: contra,
            evidenceQuotes: [snipA, snipB]
          });

          relationships.push({
            id: `rel-${findingId}`,
            sourceClauseId: cA.id,
            sourceClauseNumber: cA.clauseNumber,
            sourceTitle: cA.title,
            targetClauseId: cB.id,
            targetClauseNumber: cB.clauseNumber,
            targetTitle: cB.title,
            relationshipType: 'CONTRADICTS',
            severity: 'High',
            description: `${noticeA}-day vs ${noticeB}-day termination notice period conflict`
          });
        }
      }
    }
  }

  // 3. INTELLECTUAL PROPERTY OWNERSHIP CONTRADICTION
  for (let i = 0; i < ipClauses.length; i++) {
    for (let j = i + 1; j < ipClauses.length; j++) {
      const cA = ipClauses[i];
      const cB = ipClauses[j];

      const supplierOwnsDeliverables =
        /supplier.*retain.*(all|sole).*right, title.*deliverables|supplier foreground ip/i.test(cA.text) ||
        /supplier.*retain.*(all|sole).*right, title.*deliverables|supplier foreground ip/i.test(cB.text);

      const customerOwnsWorkForHire =
        /work made for hire.*customer|unconditionally and irrevocably assigns.*to customer.*deliverables/i.test(cA.text) ||
        /work made for hire.*customer|unconditionally and irrevocably assigns.*to customer.*deliverables/i.test(cB.text);

      if (supplierOwnsDeliverables && customerOwnsWorkForHire) {
        const findingId = `contra-${findingCounter++}`;
        const snipA = extractSnippet(cA.text, /retain|work made for hire|assign/i);
        const snipB = extractSnippet(cB.text, /retain|work made for hire|assign/i);

        const contra: ContradictionDetail = {
          clauseAId: cA.id,
          clauseANumber: cA.clauseNumber,
          clauseATitle: cA.title,
          clauseASnippet: snipA,
          clauseBId: cB.id,
          clauseBNumber: cB.clauseNumber,
          clauseBTitle: cB.title,
          clauseBSnippet: snipB,
          conflictDimension: 'IP Ownership',
          explanation: `One clause establishes that Supplier retains all intellectual property in Deliverables with only a revocable license to Customer, while the second clause classifies all Deliverables as 'work made for hire' solely owned by Customer.`
        };

        findings.push({
          id: findingId,
          severity: 'Critical',
          confidence: 96,
          type: 'Contradiction',
          title: 'Direct Conflict: Mutually Exclusive Intellectual Property Ownership',
          explanation: `${cA.clauseNumber} and ${cB.clauseNumber} contain mutually incompatible assignment language. ${cA.clauseNumber} grants Supplier ownership of foreground deliverables, whereas ${cB.clauseNumber} mandates complete transfer of Deliverables to Customer as work-made-for-hire.`,
          affectedClauseNumbers: [cA.clauseNumber, cB.clauseNumber],
          affectedClauseIds: [cA.id, cB.id],
          recommendedAction: `Clearly bifurcate Supplier Background IP (pre-existing tools and libraries) from Customer Custom Deliverables created exclusively under specific SOWs.`,
          contradiction: contra,
          evidenceQuotes: [snipA, snipB]
        });

        relationships.push({
          id: `rel-${findingId}`,
          sourceClauseId: cA.id,
          sourceClauseNumber: cA.clauseNumber,
          sourceTitle: cA.title,
          targetClauseId: cB.id,
          targetClauseNumber: cB.clauseNumber,
          targetTitle: cB.title,
          relationshipType: 'CONTRADICTS',
          severity: 'Critical',
          description: `Supplier IP retention directly contradicts Customer work-made-for-hire assignment`
        });
        break; // Only one IP contradiction pair
      }
    }
  }

  // 4. GOVERNING LAW VS ARBITRATION VENUE & FORUM CONFLICT
  for (const gov of govLawClauses) {
    for (const disp of disputeClauses) {
      if (gov.id === disp.id) continue;

      const hasNyOrUsCourt = /exclusive (?:personal and subject-matter )?jurisdiction.*(?:courts.*new york|new york county|delaware)/i.test(gov.text);
      const hasForeignArbitration = /singapore.*arbitration|siac|seat.*singapore|london.*arbitration|icc.*paris/i.test(disp.text);

      if (hasNyOrUsCourt && hasForeignArbitration) {
        const findingId = `contra-${findingCounter++}`;
        const snipA = extractSnippet(gov.text, /exclusive.*jurisdiction.*new york|delaware/i);
        const snipB = extractSnippet(disp.text, /singapore.*arbitration|siac|seat/i);

        const contra: ContradictionDetail = {
          clauseAId: gov.id,
          clauseANumber: gov.clauseNumber,
          clauseATitle: gov.title,
          clauseASnippet: snipA,
          clauseBId: disp.id,
          clauseBNumber: disp.clauseNumber,
          clauseBTitle: disp.title,
          clauseBSnippet: snipB,
          conflictDimension: 'Jurisdiction & Venue',
          explanation: `${gov.clauseNumber} subjects all disputes to the exclusive judicial forum of New York state/federal courts, while ${disp.clauseNumber} requires mandatory binding arbitration in Singapore under SIAC.`
        };

        findings.push({
          id: findingId,
          severity: 'High',
          confidence: 93,
          type: 'Jurisdiction Conflict',
          title: 'Cross-Border Forum Conflict: Exclusive NY Court Jurisdiction vs Singapore SIAC Arbitration',
          explanation: `${gov.clauseNumber} specifies that parties submit to the "exclusive jurisdiction of the State and Federal Courts located in New York", whereas ${disp.clauseNumber} mandates that all disputes be resolved via arbitration seated in Singapore under SIAC rules. This creates jurisdictional conflict over court motions vs arbitral preemption.`,
          affectedClauseNumbers: [gov.clauseNumber, disp.clauseNumber],
          affectedClauseIds: [gov.id, disp.id],
          recommendedAction: `Designate whether arbitration in Singapore is the sole forum with NY courts reserved strictly for injunctive relief, or reconcile governing law and arbitral seat.`,
          contradiction: contra,
          evidenceQuotes: [snipA, snipB]
        });

        relationships.push({
          id: `rel-${findingId}`,
          sourceClauseId: gov.id,
          sourceClauseNumber: gov.clauseNumber,
          sourceTitle: gov.title,
          targetClauseId: disp.id,
          targetClauseNumber: disp.clauseNumber,
          targetTitle: disp.title,
          relationshipType: 'CONFLICTS',
          severity: 'High',
          description: `Exclusive New York judicial forum conflicts with mandatory Singapore SIAC arbitration`
        });
      }
    }
  }

  // 5. CONFIDENTIALITY SURVIVAL PERIOD CONFLICT
  for (let i = 0; i < confidentialityClauses.length; i++) {
    for (let j = i + 1; j < confidentialityClauses.length; j++) {
      const cA = confidentialityClauses[i];
      const cB = confidentialityClauses[j];

      const surA = extractSurvivalYears(cA.text);
      const surB = extractSurvivalYears(cB.text);

      if (surA && surB && surA !== surB) {
        const findingId = `contra-${findingCounter++}`;
        const snipA = extractSnippet(cA.text, new RegExp(`${surA}\\s*years?`, 'i'));
        const snipB = extractSnippet(cB.text, new RegExp(`${surB}\\s*years?`, 'i'));

        const contra: ContradictionDetail = {
          clauseAId: cA.id,
          clauseANumber: cA.clauseNumber,
          clauseATitle: cA.title,
          clauseASnippet: snipA,
          clauseBId: cB.id,
          clauseBNumber: cB.clauseNumber,
          clauseBTitle: cB.title,
          clauseBSnippet: snipB,
          conflictDimension: 'Survival Duration',
          explanation: `${cA.clauseNumber} specifies confidentiality survives for ${surA} year(s), while ${cB.clauseNumber} mandates ${surB} years of ongoing confidentiality.`
        };

        findings.push({
          id: findingId,
          severity: 'Medium',
          confidence: 88,
          type: 'Contradiction',
          title: `Conflicting Confidentiality Survival Periods (${surA} Year vs ${surB} Years)`,
          explanation: `Discrepancy detected between confidentiality terms: ${cA.clauseNumber} terminates obligations after ${surA} year, while ${cB.clauseNumber} extends them to ${surB} years.`,
          affectedClauseNumbers: [cA.clauseNumber, cB.clauseNumber],
          affectedClauseIds: [cA.id, cB.id],
          recommendedAction: `Clarify whether trade secrets have perpetual or extended protection while general confidential information expires after ${surA} years.`,
          contradiction: contra,
          evidenceQuotes: [snipA, snipB]
        });

        relationships.push({
          id: `rel-${findingId}`,
          sourceClauseId: cA.id,
          sourceClauseNumber: cA.clauseNumber,
          sourceTitle: cA.title,
          targetClauseId: cB.id,
          targetClauseNumber: cB.clauseNumber,
          targetTitle: cB.title,
          relationshipType: 'CONTRADICTS',
          severity: 'Medium',
          description: `${surA} year vs ${surB} year survival duration mismatch`
        });
      }
    }
  }

  // 6. GENERAL SEMANTIC SIMILARITY RELATIONSHIPS (for visual network map)
  for (let i = 0; i < clauses.length; i++) {
    for (let j = i + 1; j < clauses.length; j++) {
      const c1 = clauses[i];
      const c2 = clauses[j];

      // If already linked in contradictions, skip
      if (relationships.some(r => (r.sourceClauseId === c1.id && r.targetClauseId === c2.id) || (r.sourceClauseId === c2.id && r.targetClauseId === c1.id))) {
        continue;
      }

      // Check high semantic similarity within same domain
      if (c1.category === c2.category && c1.category !== 'General Provisions') {
        const sim = computeSemanticSimilarity(c1.text, c2.text);
        if (sim > 0.35) {
          relationships.push({
            id: `rel-sim-${c1.id}-${c2.id}`,
            sourceClauseId: c1.id,
            sourceClauseNumber: c1.clauseNumber,
            sourceTitle: c1.title,
            targetClauseId: c2.id,
            targetClauseNumber: c2.clauseNumber,
            targetTitle: c2.title,
            relationshipType: 'QUALIFIES',
            severity: 'Low',
            description: `Interconnected provisions regarding ${c1.category}`
          });
        }
      }
    }
  }

  return { findings, relationships };
}

function extractNoticeDays(text: string): number | null {
  const match = text.match(/(?:([a-z]+)\s*\(([0-9]+)\)|([0-9]+))\s*(?:business\s*|calendar\s*)?days/i);
  if (!match) return null;
  const num = match[2] || match[3];
  if (num) return parseInt(num, 10);
  const wordMap: Record<string, number> = {
    thirty: 30,
    sixty: 60,
    ninety: 90,
    fifteen: 15,
    ten: 10,
    twenty: 20
  };
  const word = match[1]?.toLowerCase();
  return wordMap[word] || null;
}

function extractSurvivalYears(text: string): number | null {
  const match = text.match(/(?:([a-z]+)\s*\(([0-9]+)\)|([0-9]+))\s*years?/i);
  if (!match) return null;
  const num = match[2] || match[3];
  if (num) return parseInt(num, 10);
  const wordMap: Record<string, number> = {
    one: 1,
    two: 2,
    three: 3,
    four: 4,
    five: 5,
    seven: 7,
    ten: 10
  };
  const word = match[1]?.toLowerCase();
  return wordMap[word] || null;
}

function extractSnippet(text: string, regex: RegExp): string {
  const match = text.match(regex);
  if (!match || match.index === undefined) {
    return text.length > 140 ? text.substring(0, 140) + '...' : text;
  }
  const start = Math.max(0, match.index - 50);
  const end = Math.min(text.length, match.index + match[0].length + 90);
  let snippet = text.substring(start, end).trim();
  if (start > 0) snippet = '...' + snippet;
  if (end < text.length) snippet = snippet + '...';
  return snippet;
}
