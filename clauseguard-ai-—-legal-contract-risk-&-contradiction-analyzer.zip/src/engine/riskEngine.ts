import {
  Clause,
  RiskFinding,
  AnalysisResult,
  AnalysisSummary,
  SeverityLevel,
  ContractRelationship
} from '../types/contract';
import rulesData from './rules.json';
import { detectContradictions } from './contradictionEngine';
import { detectJurisdictions } from './jurisdictionDetector';
import { classifyAllClauses } from './clauseClassifier';

interface ContractTypeRule {
  requiredClauses: string[];
  recommendedClauses: string[];
}

export function analyzeContract(
  rawText: string,
  clauses: Clause[],
  documentName: string = 'Uploaded Contract'
): AnalysisResult {
  // 1. Classify all clauses
  const classifiedClauses = classifyAllClauses(clauses);

  // 2. Identify likely contract type
  const contractType = detectContractType(rawText);
  const typeRules = (rulesData.contractTypes as Record<string, ContractTypeRule>)[contractType] ||
    rulesData.contractTypes['Master Services Agreement'];

  // 3. Find present clause categories
  const foundCategories = new Set(classifiedClauses.map(c => c.category));

  // 4. Missing standard clauses check
  const missingFindings: RiskFinding[] = [];
  const missingClauses: string[] = [];
  const foundClausesList: string[] = [];

  for (const req of typeRules.requiredClauses) {
    if (foundCategories.has(req as any)) {
      foundClausesList.push(req);
    } else {
      missingClauses.push(req);

      let severity: SeverityLevel = 'Medium';
      if (req === 'Governing Law' || req === 'Limitation of Liability' || req === 'Termination') {
        severity = 'High';
      } else if (req === 'Insurance') {
        severity = 'Medium';
      }

      missingFindings.push({
        id: `missing-${req.toLowerCase().replace(/[^a-z0-9]/g, '-')}`,
        severity,
        confidence: 90,
        type: 'Missing Clause',
        title: `Missing Standard Clause: ${req}`,
        explanation: `The agreement is structured as a ${contractType}, but lacks a standard ${req} clause. Safe contracting principles require explicit terms addressing ${req} to prevent default common-law liabilities.`,
        affectedClauseNumbers: [],
        affectedClauseIds: [],
        recommendedAction: `Incorporate standard market ${req} provisions appropriate for a ${contractType}.`,
        missingClauseName: req
      });
    }
  }

  // 5. Potentially risky individual clauses
  const singleClauseRiskFindings: RiskFinding[] = [];
  for (const c of classifiedClauses) {
    // Check uncapped liability in liability clause
    if (c.category === 'Limitation of Liability') {
      const hasCap = /\$[0-9,]+|\bcap\b|shall not exceed|limited to the fees paid|aggregate liability/i.test(c.text);
      if (!hasCap) {
        singleClauseRiskFindings.push({
          id: `risk-uncapped-${c.id}`,
          severity: 'High',
          confidence: 86,
          type: 'Risky Clause',
          title: 'Liability Clause Lacks Explicit Monetary Cap',
          explanation: `${c.clauseNumber} (${c.title}) addresses liability limitations but does not articulate a defined monetary ceiling (e.g. 12 months fees or fixed dollar limit).`,
          affectedClauseNumbers: [c.clauseNumber],
          affectedClauseIds: [c.id],
          recommendedAction: 'Insert a mutual aggregate liability cap tied to fees paid over the preceding 12 months or a negotiated dollar sum.',
          evidenceQuotes: [c.text.substring(0, 150) + '...']
        });
      }
    }

    // Check one-sided broad indemnity
    if (c.category === 'Indemnity') {
      const isBroad = /defend, indemnify, and hold harmless.*any and all claims/i.test(c.text);
      const hasExceptions = /except to the extent caused by.*gross negligence|willful misconduct/i.test(c.text);
      if (isBroad && !hasExceptions) {
        singleClauseRiskFindings.push({
          id: `risk-indemnity-carveout-${c.id}`,
          severity: 'Medium',
          confidence: 84,
          type: 'Risky Clause',
          title: 'Broad Indemnity Lacks Gross Negligence Carve-Out',
          explanation: `${c.clauseNumber} imposes comprehensive indemnity obligations without standard statutory exclusions for indemnitee's sole negligence or willful misconduct.`,
          affectedClauseNumbers: [c.clauseNumber],
          affectedClauseIds: [c.id],
          recommendedAction: "Add customary carve-outs: 'except to the extent arising from the indemnitee’s gross negligence or willful misconduct.'",
          evidenceQuotes: [c.text.substring(0, 140) + '...']
        });
      }
    }
  }

  // 6. Contradictions between clauses
  const { findings: contradictionFindings, relationships } = detectContradictions(classifiedClauses);

  // 7. Jurisdictions detection
  const { report: jurisdictionReport, findings: jurisdictionFindings } = detectJurisdictions(classifiedClauses);

  // Aggregate all findings
  const allFindings: RiskFinding[] = [
    ...contradictionFindings,
    ...jurisdictionFindings,
    ...missingFindings,
    ...singleClauseRiskFindings
  ];

  // Sort findings by severity: Critical > High > Medium > Low
  const severityRank: Record<SeverityLevel, number> = {
    Critical: 4,
    High: 3,
    Medium: 2,
    Low: 1
  };

  allFindings.sort((a, b) => {
    const diff = severityRank[b.severity] - severityRank[a.severity];
    if (diff !== 0) return diff;
    return b.confidence - a.confidence;
  });

  // Calculate summary metrics
  const criticalCount = allFindings.filter(f => f.severity === 'Critical').length;
  const highCount = allFindings.filter(f => f.severity === 'High').length;
  const mediumCount = allFindings.filter(f => f.severity === 'Medium').length;
  const lowCount = allFindings.filter(f => f.severity === 'Low').length;

  let overallRisk: SeverityLevel = 'Low';
  if (criticalCount > 0) {
    overallRisk = 'Critical';
  } else if (highCount > 0) {
    overallRisk = 'High';
  } else if (mediumCount > 1) {
    overallRisk = 'Medium';
  }

  const summary: AnalysisSummary = {
    overallRisk,
    totalClauses: classifiedClauses.length,
    totalRisks: allFindings.length,
    contradictionsCount: contradictionFindings.length,
    missingClausesCount: missingFindings.length,
    jurisdictionIssuesCount: jurisdictionReport.hasConflict ? 1 : 0,
    contractTypeDetected: contractType,
    estimatedPages: Math.max(1, Math.ceil(rawText.length / 2600)),
    criticalCount,
    highCount,
    mediumCount,
    lowCount
  };

  return {
    documentName,
    documentText: rawText,
    clauses: classifiedClauses,
    findings: allFindings,
    relationships,
    jurisdictionReport,
    summary,
    safeRulesetResults: {
      expectedClauses: typeRules.requiredClauses,
      foundClauses: foundClausesList,
      missingClauses
    },
    analyzedAt: new Date().toISOString()
  };
}

function detectContractType(rawText: string): string {
  const lower = rawText.substring(0, 1000).toLowerCase();

  if (/master services|msa|consulting services agreement/i.test(lower)) {
    return 'Master Services Agreement';
  }
  if (/non-disclosure|nondisclosure|nda|confidentiality agreement/i.test(lower)) {
    return 'Non-Disclosure Agreement';
  }
  if (/software license|saas|subscription agreement|end user/i.test(lower)) {
    return 'Software License / SaaS Agreement';
  }
  if (/vendor agreement|supplier agreement|procurement/i.test(lower)) {
    return 'Vendor Agreement';
  }

  return 'Master Services Agreement';
}
