import { AnalysisResult } from '../types/contract';

export function generateStructuredReportText(result: AnalysisResult): string {
  const { summary, findings, jurisdictionReport, safeRulesetResults, documentName, analyzedAt } = result;

  const dateStr = new Date(analyzedAt).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });

  const divider = '='.repeat(78);
  const subDivider = '-'.repeat(78);

  const lines: string[] = [];

  lines.push(divider);
  lines.push('CLAUSEGUARD AI — CONTRACT RISK & CONTRADICTION AUDIT REPORT');
  lines.push('Automated Legal Contract Analysis System (MVP)');
  lines.push(divider);
  lines.push(`Document Name:       ${documentName}`);
  lines.push(`Detected Type:       ${summary.contractTypeDetected}`);
  lines.push(`Audit Timestamp:     ${dateStr}`);
  lines.push(`Overall Risk Rating: ${summary.overallRisk.toUpperCase()}`);
  lines.push(subDivider);
  lines.push('EXECUTIVE SUMMARY:');
  lines.push(`• Total Clauses Analyzed:      ${summary.totalClauses}`);
  lines.push(`• Total Risk Findings:         ${summary.totalRisks}`);
  lines.push(`• Critical Contradictions:     ${summary.contradictionsCount}`);
  lines.push(`• Missing Safe Clauses:        ${summary.missingClausesCount}`);
  lines.push(`• Cross-Jurisdiction Flags:    ${summary.jurisdictionIssuesCount}`);
  lines.push(`• Severity Breakdown:          ${summary.criticalCount} Critical | ${summary.highCount} High | ${summary.mediumCount} Medium | ${summary.lowCount} Low`);
  lines.push('');
  lines.push('DISCLAIMER: ClauseGuard AI is an automated risk identification tool for commercial review.');
  lines.push('This report does not constitute binding legal advice and must be verified by licensed counsel.');
  lines.push(divider);
  lines.push('');

  // 1. CRITICAL CONTRADICTIONS SECTION
  const contradictions = findings.filter(f => f.type === 'Contradiction');
  lines.push('SECTION 1: DETECTED CLAUSE CONTRADICTIONS (MUTUALLY EXCLUSIVE PROVISIONS)');
  lines.push(subDivider);

  if (contradictions.length === 0) {
    lines.push('No direct textual contradictions detected between clauses.');
  } else {
    contradictions.forEach((c, idx) => {
      lines.push(`[1.${idx + 1}] [SEVERITY: ${c.severity.toUpperCase()}] ${c.title}`);
      lines.push(`Affected Clauses: ${c.affectedClauseNumbers.join(' <--> ')}`);
      lines.push(`Confidence Level: ${c.confidence}%`);
      lines.push(`Analysis:         ${c.explanation}`);

      if (c.contradiction) {
        lines.push('');
        lines.push(`  Evidence 1 (${c.contradiction.clauseANumber} - ${c.contradiction.clauseATitle}):`);
        lines.push(`  "${c.contradiction.clauseASnippet.trim()}"`);
        lines.push('');
        lines.push(`  Evidence 2 (${c.contradiction.clauseBNumber} - ${c.contradiction.clauseBTitle}):`);
        lines.push(`  "${c.contradiction.clauseBSnippet.trim()}"`);
      }
      lines.push('');
      lines.push(`Recommended Action: ${c.recommendedAction}`);
      lines.push('');
    });
  }
  lines.push(divider);
  lines.push('');

  // 2. JURISDICTION & GOVERNING LAW ANALYSIS
  lines.push('SECTION 2: JURISDICTION & DISPUTE FORUM MATRIX');
  lines.push(subDivider);
  lines.push(`Detected Frameworks: ${jurisdictionReport.detectedJurisdictions.join(', ') || 'None specified'}`);
  lines.push(`Cross-Border Friction: ${jurisdictionReport.hasConflict ? 'YES - REVIEW REQUIRED' : 'NO'}`);

  if (jurisdictionReport.notes.length > 0) {
    jurisdictionReport.notes.forEach(note => lines.push(`• ${note}`));
  }

  if (jurisdictionReport.mentions.length > 0) {
    lines.push('');
    lines.push('Specific References:');
    jurisdictionReport.mentions.forEach(m => {
      lines.push(`  [${m.clauseNumber}] ${m.name} -> ${m.context}`);
    });
  }
  lines.push('');
  lines.push(divider);
  lines.push('');

  // 3. MISSING STANDARD CLAUSES
  lines.push('SECTION 3: MISSING SAFE-CONTRACT CLAUSES');
  lines.push(subDivider);
  lines.push(`Standard Required Clauses for ${summary.contractTypeDetected}:`);
  safeRulesetResults.expectedClauses.forEach(req => {
    const isPresent = safeRulesetResults.foundClauses.includes(req);
    lines.push(`  [${isPresent ? 'PRESENT' : 'MISSING'}] ${req}`);
  });

  if (safeRulesetResults.missingClauses.length > 0) {
    lines.push('');
    lines.push('Missing Clause Risk Assessment:');
    safeRulesetResults.missingClauses.forEach(m => {
      lines.push(`• ${m}: Safe commercial contracting requires an express ${m} provision to avoid statutory or common-law default rules.`);
    });
  }
  lines.push('');
  lines.push(divider);
  lines.push('');

  // 4. ACTIONABLE LEGAL MITIGATION CHECKLIST
  lines.push('SECTION 4: ACTIONABLE MITIGATION CHECKLIST FOR COUNSEL');
  lines.push(subDivider);
  findings.forEach((f, idx) => {
    lines.push(`[ ] Item ${idx + 1} (${f.severity} - ${f.affectedClauseNumbers.join('/') || f.missingClauseName || 'General'}):`);
    lines.push(`    ${f.recommendedAction}`);
  });
  lines.push('');
  lines.push(divider);
  lines.push('END OF REPORT — CLAUSEGUARD AI');
  lines.push(divider);

  return lines.join('\n');
}

export function downloadTextFile(filename: string, content: string): void {
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
