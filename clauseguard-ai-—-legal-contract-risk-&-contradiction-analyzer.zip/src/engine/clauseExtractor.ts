import * as mammoth from 'mammoth';
import { Clause } from '../types/contract';

/**
 * Extracts plain text from an uploaded File (PDF, DOCX, or TXT/MD).
 */
export async function extractTextFromFile(file: File): Promise<{ text: string; pagesEstimate: number }> {
  const extension = file.name.split('.').pop()?.toLowerCase();

  if (extension === 'docx') {
    const arrayBuffer = await file.arrayBuffer();
    const result = await mammoth.extractRawText({ arrayBuffer });
    const text = result.value || '';
    const pagesEstimate = Math.max(1, Math.ceil(text.length / 2800));
    return { text, pagesEstimate };
  }

  if (extension === 'pdf') {
    try {
      const arrayBuffer = await file.arrayBuffer();
      const pdfjsLib = await import('pdfjs-dist');
      
      // Try setting worker or using fake worker mode
      try {
        if (!pdfjsLib.GlobalWorkerOptions.workerSrc) {
          pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.mjs`;
        }
      } catch {
        // Continue with default worker
      }

      const loadingTask = pdfjsLib.getDocument({
        data: new Uint8Array(arrayBuffer),
        useSystemFonts: true,
      });

      const pdf = await loadingTask.promise;
      let fullText = '';
      const numPages = pdf.numPages;

      for (let pageNum = 1; pageNum <= numPages; pageNum++) {
        const page = await pdf.getPage(pageNum);
        const textContent = await page.getTextContent();
        const pageText = textContent.items
          .map((item: any) => ('str' in item ? item.str : ''))
          .join(' ');
        fullText += `\n[--- Page ${pageNum} ---]\n` + pageText;
      }

      return { text: fullText.trim(), pagesEstimate: numPages };
    } catch (pdfErr) {
      console.warn('PDF parsing with pdfjs-dist failed, attempting raw binary string extraction fallback', pdfErr);
      // Fallback: read text representation
      const text = await file.text();
      return { text: cleanBinaryString(text), pagesEstimate: 1 };
    }
  }

  // Fallback for TXT, MD, etc.
  const text = await file.text();
  const pagesEstimate = Math.max(1, Math.ceil(text.length / 2500));
  return { text, pagesEstimate };
}

function cleanBinaryString(raw: string): string {
  // Strip control chars from raw streams
  return raw
    .replace(/[^\x20-\x7E\t\r\n]/g, ' ')
    .replace(/\s{2,}/g, ' ')
    .trim();
}

/**
 * Splits legal contract text into structured Clause objects.
 * Handles headings, numbered sections (1., 1.1, Clause 1, Section 1, Article I), and paragraphs.
 */
export function segmentContractIntoClauses(rawText: string): Clause[] {
  const lines = rawText.split(/\r?\n/);
  const clauses: Clause[] = [];

  let currentNumber = '';
  let currentTitle = '';
  let currentLines: string[] = [];
  let currentPage = 1;
  let clauseIndexCounter = 1;

  // Patterns for clause headers
  // e.g. "1. DEFINITIONS", "SECTION 10. LIMITATION OF LIABILITY", "10.2 AGGREGATE LIABILITY CAP"
  // "Article IV: Governing Law", "Clause 14. Termination", "1.1 Services"
  const clauseHeaderRegex = /^(?:(?:Section|SECTION|Article|ARTICLE|Clause|CLAUSE)\s+([0-9IVXLCDM]+(?:\.[0-9]+)*)|([0-9]+(?:\.[0-9]+)*))\s*[:.\-–—]\s*(.*)$/i;
  const standaloneNumberedRegex = /^(?:(?:Section|SECTION|Article|ARTICLE|Clause|CLAUSE)\s+([0-9IVXLCDM]+(?:\.[0-9]+)*)|([0-9]+(?:\.[0-9]+)*))\s*$/i;

  const pushCurrentClause = () => {
    if (currentLines.length === 0 && !currentTitle) return;

    const fullText = currentLines.join('\n').trim();
    if (!fullText && !currentTitle) return;

    // Filter out pure boilerplate recitals or short empty separators if needed
    const clauseNum = currentNumber || `Clause ${clauseIndexCounter}`;
    const title = currentTitle || inferTitleFromText(fullText) || `Clause ${clauseIndexCounter}`;

    const keyEntities = extractKeyEntities(fullText);

    clauses.push({
      id: `clause-${clauseIndexCounter}`,
      numericIndex: clauseIndexCounter,
      clauseNumber: clauseNum,
      title: title.replace(/^[:.\-–—\s]+/, '').trim(),
      text: fullText || title,
      pageNumber: currentPage,
      category: 'General Provisions', // Will be updated by classifier
      categoryConfidence: 50,
      keyEntities
    });

    clauseIndexCounter++;
    currentLines = [];
    currentNumber = '';
    currentTitle = '';
  };

  for (let i = 0; i < lines.length; i++) {
    const rawLine = lines[i];
    const trimmedLine = rawLine.trim();

    // Check for page markers
    const pageMatch = trimmedLine.match(/\[--- Page (\d+) ---\]/i);
    if (pageMatch) {
      currentPage = parseInt(pageMatch[1], 10);
      continue;
    }

    if (!trimmedLine) {
      if (currentLines.length > 0) {
        currentLines.push('');
      }
      continue;
    }

    // Check if line matches a numbered clause header
    const headerMatch = trimmedLine.match(clauseHeaderRegex);
    const standaloneMatch = trimmedLine.match(standaloneNumberedRegex);

    if (headerMatch) {
      pushCurrentClause();
      const num = headerMatch[1] || headerMatch[2];
      const rest = headerMatch[3]?.trim() || '';
      currentNumber = num ? `Section ${num}` : `Clause ${clauseIndexCounter}`;
      currentTitle = rest;
      continue;
    } else if (standaloneMatch) {
      pushCurrentClause();
      const num = standaloneMatch[1] || standaloneMatch[2];
      currentNumber = `Section ${num}`;
      // Peek next line to see if it looks like a title
      if (i + 1 < lines.length && lines[i + 1].trim().length < 80) {
        currentTitle = lines[i + 1].trim();
        i++;
      }
      continue;
    }

    // Check for all-caps section titles (e.g. "RECITALS", "INDEMNIFICATION OBLIGATIONS")
    const isAllCapsTitle =
      trimmedLine.length > 3 &&
      trimmedLine.length < 75 &&
      trimmedLine === trimmedLine.toUpperCase() &&
      !/[.?!]$/.test(trimmedLine) &&
      !trimmedLine.includes('{') &&
      !trimmedLine.includes(';') &&
      /^[A-Z0-9\s,&/\-()]+$/.test(trimmedLine);

    if (isAllCapsTitle && currentLines.length > 0) {
      pushCurrentClause();
      currentNumber = `Clause ${clauseIndexCounter}`;
      currentTitle = trimmedLine;
      continue;
    }

    currentLines.push(trimmedLine);
  }

  // Push final clause
  pushCurrentClause();

  // If no numbered clauses were detected (e.g. unbroken text), split by double newlines or paragraphs
  if (clauses.length <= 1 && rawText.length > 300) {
    return fallbackParagraphSplit(rawText);
  }

  return clauses;
}

function fallbackParagraphSplit(rawText: string): Clause[] {
  const paragraphs = rawText
    .split(/\n\s*\n/)
    .map(p => p.trim())
    .filter(p => p.length > 25);

  return paragraphs.map((p, idx) => {
    const lines = p.split('\n');
    const firstLine = lines[0].trim();
    const title = firstLine.length < 70 ? firstLine : inferTitleFromText(p);

    return {
      id: `clause-${idx + 1}`,
      numericIndex: idx + 1,
      clauseNumber: `Paragraph ${idx + 1}`,
      title,
      text: p,
      pageNumber: 1,
      category: 'General Provisions',
      categoryConfidence: 50,
      keyEntities: extractKeyEntities(p)
    };
  });
}

function inferTitleFromText(text: string): string {
  const firstSentence = text.split(/[.?!]/)[0]?.trim() || '';
  if (firstSentence.length > 0 && firstSentence.length <= 60) {
    return firstSentence;
  }
  return text.substring(0, 50) + '...';
}

function extractKeyEntities(text: string): Clause['keyEntities'] {
  const entities: Clause['keyEntities'] = {};

  // Notice periods (e.g., 30 days, sixty (60) days, 90 days)
  const noticeMatch = text.match(/(?:(?:within|upon|least|prior)\s+)?(?:([a-z]+)\s*\(([0-9]+)\)|([0-9]+))\s*(?:business\s*|calendar\s*)?days/gi);
  if (noticeMatch) {
    entities.noticePeriods = Array.from(new Set(noticeMatch.map(m => m.trim())));
  }

  // Durations & Survival (e.g., 1 year, 2 years, 5 years, ninety (90) days, in perpetuity)
  const durationMatch = text.match(/(?:for a period of\s+|survive\s+(?:for\s+)?)(?:(?:([a-z]+)\s*\(([0-9]+)\)|([0-9]+))\s*(?:years?|months?)|perpetuity)/gi);
  if (durationMatch) {
    entities.durations = Array.from(new Set(durationMatch.map(m => m.trim())));
  }

  // Monetary values (e.g., $50,000, 50,000 U.S. Dollars, $1,000,000)
  const moneyMatch = text.match(/\$[0-9,]+(?:\.[0-9]{2})?|\b[0-9,]+\s*(?:U\.S\.\s*Dollars|USD|EUR|GBP)\b/gi);
  if (moneyMatch) {
    entities.monetaryValues = Array.from(new Set(moneyMatch.map(m => m.trim())));
  }

  // Jurisdictions
  const jurisdictions: string[] = [];
  const jurKeywords = [
    'New York', 'California', 'Delaware', 'Singapore', 'United Kingdom', 'England and Wales',
    'United States', 'EU', 'European Union', 'GDPR', 'India', 'Australia', 'Hong Kong'
  ];
  for (const j of jurKeywords) {
    if (new RegExp(`\\b${j}\\b`, 'i').test(text)) {
      jurisdictions.push(j);
    }
  }
  if (jurisdictions.length > 0) {
    entities.jurisdictions = jurisdictions;
  }

  return entities;
}
