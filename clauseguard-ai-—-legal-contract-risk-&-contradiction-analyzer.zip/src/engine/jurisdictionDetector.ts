import { Clause, JurisdictionReport, JurisdictionMention, RiskFinding } from '../types/contract';

interface JurisdictionPattern {
  name: string;
  region: 'US' | 'EU/UK' | 'APAC' | 'GLOBAL';
  regex: RegExp;
  statutoryImplications: string;
}

const JURISDICTION_PATTERNS: JurisdictionPattern[] = [
  {
    name: 'State of New York',
    region: 'US',
    regex: /\b(?:New York|State of New York|NY County|New York County)\b/i,
    statutoryImplications: 'UCC Article 2, NY General Obligations Law § 5-1401'
  },
  {
    name: 'State of California',
    region: 'US',
    regex: /\b(?:California|State of California|CCPA|California Consumer Privacy Act)\b/i,
    statutoryImplications: 'CCPA/CPRA, CA Business & Professions Code § 16600 (strict non-compete voidance)'
  },
  {
    name: 'State of Delaware',
    region: 'US',
    regex: /\b(?:Delaware|State of Delaware|Wilmington, Delaware)\b/i,
    statutoryImplications: 'Delaware General Corporation Law (DGCL)'
  },
  {
    name: 'Singapore',
    region: 'APAC',
    regex: /\b(?:Singapore|Singapore International Arbitration Centre|SIAC)\b/i,
    statutoryImplications: 'International Arbitration Act (Cap. 143A), New York Convention 1958'
  },
  {
    name: 'European Union (GDPR)',
    region: 'EU/UK',
    regex: /\b(?:European Union|EEA|European Economic Area|GDPR|Regulation EU 2016\/679)\b/i,
    statutoryImplications: 'GDPR Chapter V Cross-Border Transfer Mechanisms (SCCs, Adequacy)'
  },
  {
    name: 'United Kingdom',
    region: 'EU/UK',
    regex: /\b(?:United Kingdom|England and Wales|English Law|High Court of Justice in London)\b/i,
    statutoryImplications: 'UK GDPR / Data Protection Act 2018, Contracts (Rights of Third Parties) Act 1999'
  },
  {
    name: 'India',
    region: 'APAC',
    regex: /\b(?:India|Indian Contract Act|Delhi High Court|Mumbai)\b/i,
    statutoryImplications: 'Indian Contract Act 1872, Digital Personal Data Protection Act 2023'
  },
  {
    name: 'Australia',
    region: 'APAC',
    regex: /\b(?:Australia|Commonwealth of Australia|NSW|Federal Court of Australia)\b/i,
    statutoryImplications: 'Australian Consumer Law (ACL), Privacy Act 1988'
  }
];

export function detectJurisdictions(clauses: Clause[]): {
  report: JurisdictionReport;
  findings: RiskFinding[];
} {
  const mentions: JurisdictionMention[] = [];
  const detectedSet = new Set<string>();
  const regionsSet = new Set<string>();

  for (const clause of clauses) {
    for (const pattern of JURISDICTION_PATTERNS) {
      if (pattern.regex.test(clause.text) || pattern.regex.test(clause.title)) {
        detectedSet.add(pattern.name);
        regionsSet.add(pattern.region);

        // Find match context
        const match = clause.text.match(pattern.regex);
        const matchIndex = match?.index || 0;
        const start = Math.max(0, matchIndex - 30);
        const end = Math.min(clause.text.length, matchIndex + 70);
        const context = clause.text.substring(start, end).replace(/\s+/g, ' ').trim();

        mentions.push({
          name: pattern.name,
          clauseId: clause.id,
          clauseNumber: clause.clauseNumber,
          context: `...${context}...`
        });
      }
    }
  }

  const detectedList = Array.from(detectedSet);
  const findings: RiskFinding[] = [];
  const notes: string[] = [];

  // Flag cross-jurisdiction if multiple distinct jurisdictions / regions appear
  const hasMultipleJurisdictions = detectedList.length >= 2;
  const hasTranscontinentalClash = regionsSet.size >= 2;

  if (hasMultipleJurisdictions) {
    const affectedClauseNumbers = Array.from(new Set(mentions.map(m => m.clauseNumber)));
    const affectedClauseIds = Array.from(new Set(mentions.map(m => m.clauseId)));

    const isHigh = hasTranscontinentalClash || (detectedSet.has('Singapore') && (detectedSet.has('State of New York') || detectedSet.has('State of Delaware')));

    notes.push(`Detected ${detectedList.length} distinct legal frameworks across ${regionsSet.size} global jurisdictions.`);
    
    if (detectedSet.has('European Union (GDPR)') && (detectedSet.has('State of New York') || detectedSet.has('State of California'))) {
      notes.push('Contract references EU GDPR data processing while specifying US governing law without explicit Standard Contractual Clauses (SCCs).');
    }

    findings.push({
      id: 'jur-cross-border-conflict',
      severity: isHigh ? 'High' : 'Medium',
      confidence: 89,
      type: 'Jurisdiction Conflict',
      title: 'Cross-Jurisdiction Review Required',
      explanation: `The agreement references multiple jurisdictions: ${detectedList.join(', ')}. Discrepancies between statutory requirements (such as US State governing law vs foreign arbitral seats or EU GDPR cross-border transfer rules) introduce choice-of-law and enforcement friction.`,
      affectedClauseNumbers,
      affectedClauseIds,
      recommendedAction: 'Engage legal counsel to harmonize choice-of-law provisions, align dispute resolution seats, and verify international data transfer mechanisms (e.g. EU SCCs).',
      jurisdictionsDetected: detectedList,
      evidenceQuotes: mentions.slice(0, 3).map(m => `[${m.clauseNumber}] (${m.name}): ${m.context}`)
    });
  }

  return {
    report: {
      detectedJurisdictions: detectedList,
      mentions,
      hasConflict: hasMultipleJurisdictions,
      notes
    },
    findings
  };
}
