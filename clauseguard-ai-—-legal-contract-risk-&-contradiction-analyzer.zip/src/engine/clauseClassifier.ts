import { Clause, ClauseCategory } from '../types/contract';

interface CategoryRule {
  category: ClauseCategory;
  titleKeywords: string[];
  bodyKeywords: string[];
  negativeKeywords?: string[];
  weight: number;
}

const CATEGORY_RULES: CategoryRule[] = [
  {
    category: 'Limitation of Liability',
    titleKeywords: ['liability', 'limitation of liability', 'liability cap', 'consequential damages', 'indirect damages'],
    bodyKeywords: ['aggregate liability', 'shall not exceed', 'in no event shall', 'punitive damages', 'loss of profits', 'disclaimer of damages', 'liability cap', 'maximum liability'],
    weight: 1.4
  },
  {
    category: 'Indemnity',
    titleKeywords: ['indemnity', 'indemnification', 'hold harmless', 'defense'],
    bodyKeywords: ['indemnify', 'hold harmless', 'defend and hold', 'indemnitee', 'indemnitor', 'infringement claim', 'third-party claim', 'attorneys\' fees'],
    weight: 1.3
  },
  {
    category: 'Termination',
    titleKeywords: ['termination', 'term and termination', 'expiration', 'cancellation'],
    bodyKeywords: ['terminate this agreement', 'written notice of termination', 'cure period', 'material breach', 'for convenience', 'for cause', 'insolvency', 'bankruptcy', 'wind-down'],
    weight: 1.2
  },
  {
    category: 'Confidentiality',
    titleKeywords: ['confidential', 'confidentiality', 'non-disclosure', 'trade secret', 'proprietary information'],
    bodyKeywords: ['confidential information', 'disclosing party', 'receiving party', 'non-disclosure', 'degree of care', 'survive expiration', 'trade secrets', 'return of materials'],
    weight: 1.2
  },
  {
    category: 'Intellectual Property',
    titleKeywords: ['intellectual property', 'ip', 'proprietary rights', 'work made for hire', 'ownership', 'deliverables', 'copyrights', 'patents', 'licensing'],
    bodyKeywords: ['intellectual property rights', 'work product', 'work made for hire', 'assigns, transfers and conveys', 'copyrights, patents', 'trade secrets', 'pre-existing rights', 'background technology', 'foreground ip', 'license grant'],
    weight: 1.3
  },
  {
    category: 'Governing Law',
    titleKeywords: ['governing law', 'applicable law', 'jurisdiction', 'choice of law', 'legal forum'],
    bodyKeywords: ['governed by and construed', 'internal laws of the state', 'conflict of law principles', 'exclusive jurisdiction of the courts', 'venue', 'forum non conveniens'],
    weight: 1.3
  },
  {
    category: 'Dispute Resolution',
    titleKeywords: ['dispute resolution', 'arbitration', 'mediation', 'dispute', 'litigation'],
    bodyKeywords: ['binding arbitration', 'siac', 'american arbitration association', 'aaa', 'icc rules', 'arbitrator', 'tribunal', 'seat of arbitration', 'rules of arbitration'],
    weight: 1.3
  },
  {
    category: 'Payment',
    titleKeywords: ['payment', 'fees', 'compensation', 'invoicing', 'billing', 'taxes', 'expenses'],
    bodyKeywords: ['invoices', 'net 30', 'net 60', 'interest on past due', 'hourly rate', 'retainer', 'expenses reimbursable', 'sales tax', 'vat', 'wire transfer'],
    weight: 1.2
  },
  {
    category: 'Data Protection',
    titleKeywords: ['data protection', 'privacy', 'security', 'gdpr', 'ccpa', 'personal data'],
    bodyKeywords: ['data processor', 'data controller', 'gdpr', 'general data protection regulation', 'personal data', 'ccpa', 'data breach', 'technical and organizational measures', 'privacy act'],
    weight: 1.3
  },
  {
    category: 'Warranty',
    titleKeywords: ['warranty', 'warranties', 'disclaimer', 'guarantee', 'as-is'],
    bodyKeywords: ['warrants that the services', 'as is', 'implied warranties', 'merchantability', 'fitness for a particular purpose', 'remedy for breach of warranty', 'defect'],
    weight: 1.2
  },
  {
    category: 'Force Majeure',
    titleKeywords: ['force majeure', 'acts of god', 'unforeseen events', 'excused performance'],
    bodyKeywords: ['acts of god', 'strikes', 'riots', 'war', 'terrorism', 'natural disasters', 'beyond its reasonable control', 'resumption of performance'],
    weight: 1.3
  },
  {
    category: 'Insurance',
    titleKeywords: ['insurance', 'coverage', 'policies', 'commercial general liability', 'errors and omissions', 'cyber insurance'],
    bodyKeywords: ['commercial general liability', 'errors and omissions', 'workers compensation', 'certificate of insurance', 'additional insured', 'policy limits', 'minimum coverage'],
    weight: 1.3
  },
  {
    category: 'Assignment',
    titleKeywords: ['assignment', 'subcontracting', 'successors', 'delegation'],
    bodyKeywords: ['shall not assign', 'written consent of', 'subcontractors', 'merger or acquisition', 'binding upon successors and assigns'],
    weight: 1.2
  },
  {
    category: 'Non-Compete',
    titleKeywords: ['non-compete', 'non-solicitation', 'restrictive covenants'],
    bodyKeywords: ['shall not solicit', 'compete directly or indirectly', 'customers or employees', 'restraint of trade'],
    weight: 1.2
  }
];

export function classifyClause(clause: Clause): { category: ClauseCategory; confidence: number } {
  const titleLower = clause.title.toLowerCase();
  const textLower = clause.text.toLowerCase();

  let bestCategory: ClauseCategory = 'General Provisions';
  let highestScore = 0;

  for (const rule of CATEGORY_RULES) {
    let score = 0;

    // Check title matches (stronger weight)
    for (const kw of rule.titleKeywords) {
      if (titleLower.includes(kw)) {
        score += 45 * rule.weight;
      }
    }

    // Check body keyword matches
    for (const kw of rule.bodyKeywords) {
      if (textLower.includes(kw)) {
        score += 15 * rule.weight;
      }
    }

    if (score > highestScore) {
      highestScore = score;
      bestCategory = rule.category;
    }
  }

  // Calculate confidence capped at 98%
  let confidence = 50;
  if (highestScore > 80) confidence = 95;
  else if (highestScore > 50) confidence = 85;
  else if (highestScore > 30) confidence = 75;
  else if (highestScore > 15) confidence = 65;

  return {
    category: bestCategory,
    confidence
  };
}

export function classifyAllClauses(clauses: Clause[]): Clause[] {
  return clauses.map(c => {
    const { category, confidence } = classifyClause(c);
    return {
      ...c,
      category,
      categoryConfidence: confidence
    };
  });
}
