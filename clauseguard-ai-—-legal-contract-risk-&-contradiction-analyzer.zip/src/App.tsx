/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { HeroUpload } from './components/HeroUpload';
import { AnalysisSummaryBar } from './components/AnalysisSummaryBar';
import { ContractReader } from './components/ContractReader';
import { FindingsPanel } from './components/FindingsPanel';
import { ContractRiskMap } from './components/ContractRiskMap';
import { ClauseComparisonModal } from './components/ClauseComparisonModal';
import { ReportModal } from './components/ReportModal';
import { RulesetModal } from './components/RulesetModal';

import { DEMO_MASTER_SERVICES_AGREEMENT, SAMPLE_NDA_CONTRACT } from './data/sampleContracts';
import { extractTextFromFile, segmentContractIntoClauses } from './engine/clauseExtractor';
import { analyzeContract } from './engine/riskEngine';
import { AnalysisResult, Clause, RiskFinding } from './types/contract';

export default function App() {
  const [activeView, setActiveView] = useState<'split' | 'map'>('split');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [processingStep, setProcessingStep] = useState<string>('');
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);

  // Interaction states
  const [selectedFinding, setSelectedFinding] = useState<RiskFinding | null>(null);
  const [comparisonModalFinding, setComparisonModalFinding] = useState<RiskFinding | null>(null);
  const [isReportOpen, setIsReportOpen] = useState<boolean>(false);
  const [isRulesetOpen, setIsRulesetOpen] = useState<boolean>(false);
  const [activeTypeFilter, setActiveTypeFilter] = useState<string>('all');

  // Load demo contract initially on mount
  useEffect(() => {
    loadContractFromText(
      DEMO_MASTER_SERVICES_AGREEMENT.text,
      DEMO_MASTER_SERVICES_AGREEMENT.name
    );
  }, []);

  const loadContractFromText = async (rawText: string, docName: string) => {
    setIsProcessing(true);
    setProcessingStep('Extracting document clauses...');

    setTimeout(() => {
      try {
        setProcessingStep('Segmenting numbered clauses...');
        const rawClauses = segmentContractIntoClauses(rawText);

        setProcessingStep('Evaluating safe ruleset & contradictions...');
        const result = analyzeContract(rawText, rawClauses, docName);

        setAnalysisResult(result);
        if (result.findings.length > 0) {
          // Select first critical or first finding
          setSelectedFinding(result.findings[0]);
        }
      } catch (err) {
        console.error('Contract analysis failed:', err);
      } finally {
        setIsProcessing(false);
        setProcessingStep('');
      }
    }, 250);
  };

  const handleAnalyzeFile = async (file: File) => {
    setIsProcessing(true);
    setProcessingStep(`Parsing ${file.name.endsWith('.docx') ? 'DOCX' : 'PDF'} structure...`);

    try {
      const { text } = await extractTextFromFile(file);

      if (!text || text.trim().length < 50) {
        alert('Could not extract readable text from the uploaded file. Please ensure it is not an image-only scanned PDF.');
        setIsProcessing(false);
        return;
      }

      setProcessingStep('Segmenting clauses and headings...');
      const rawClauses = segmentContractIntoClauses(text);

      setProcessingStep('Analyzing contradictions & risk rules...');
      const result = analyzeContract(text, rawClauses, file.name);

      setAnalysisResult(result);
      if (result.findings.length > 0) {
        setSelectedFinding(result.findings[0]);
      }
    } catch (err) {
      console.error('File parsing error:', err);
      alert('Error parsing uploaded file. You can also paste the contract text directly.');
    } finally {
      setIsProcessing(false);
      setProcessingStep('');
    }
  };

  const handleSelectClause = (clause: Clause) => {
    if (!analysisResult) return;
    // Look for finding affecting this clause
    const matchedFinding = analysisResult.findings.find(f =>
      f.affectedClauseIds.includes(clause.id)
    );
    if (matchedFinding) {
      setSelectedFinding(matchedFinding);
    }
  };

  const handleSelectFindingByClauseId = (clauseId: string) => {
    if (!analysisResult) return;
    const matchedFinding = analysisResult.findings.find(
      f => f.type === 'Contradiction' && f.affectedClauseIds.includes(clauseId)
    );
    if (matchedFinding) {
      setSelectedFinding(matchedFinding);
      setComparisonModalFinding(matchedFinding);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans antialiased selection:bg-slate-900 selection:text-white">
      {/* Top Header */}
      <Header
        activeView={activeView}
        setActiveView={setActiveView}
        onOpenReport={() => setIsReportOpen(true)}
        onOpenRules={() => setIsRulesetOpen(true)}
        onLoadDemo={() =>
          loadContractFromText(
            DEMO_MASTER_SERVICES_AGREEMENT.text,
            DEMO_MASTER_SERVICES_AGREEMENT.name
          )
        }
        hasAnalysis={!!analysisResult}
      />

      {/* Hero Upload & Input Section */}
      <HeroUpload
        onAnalyzeText={loadContractFromText}
        onAnalyzeFile={handleAnalyzeFile}
        onLoadDemo={() =>
          loadContractFromText(
            DEMO_MASTER_SERVICES_AGREEMENT.text,
            DEMO_MASTER_SERVICES_AGREEMENT.name
          )
        }
        isProcessing={isProcessing}
        processingStep={processingStep}
      />

      {/* Main Workspace */}
      {analysisResult && (
        <main className="flex-1 flex flex-col">
          {/* High-Density Summary Bar */}
          <AnalysisSummaryBar
            summary={analysisResult.summary}
            onFilterFindings={type => {
              setActiveTypeFilter(type);
              setActiveView('split');
            }}
            activeFilter={activeTypeFilter}
          />

          {/* View Switcher: Split-Screen or Risk Map */}
          {activeView === 'split' ? (
            <div className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-[780px] bg-white rounded-lg border border-slate-200 overflow-hidden shadow-xs">
                {/* LEFT: Contract Document Stream (7 Cols) */}
                <div className="lg:col-span-7 h-full overflow-hidden">
                  <ContractReader
                    clauses={analysisResult.clauses}
                    selectedFinding={selectedFinding}
                    onSelectClause={handleSelectClause}
                    onSelectFindingByClauseId={handleSelectFindingByClauseId}
                    allFindings={analysisResult.findings}
                  />
                </div>

                {/* RIGHT: Risk Findings Panel (5 Cols) */}
                <div className="lg:col-span-5 h-full overflow-hidden">
                  <FindingsPanel
                    findings={analysisResult.findings}
                    selectedFinding={selectedFinding}
                    onSelectFinding={f => setSelectedFinding(f)}
                    onOpenComparisonModal={f => setComparisonModalFinding(f)}
                    activeTypeFilter={activeTypeFilter}
                    onSetTypeFilter={setActiveTypeFilter}
                  />
                </div>
              </div>
            </div>
          ) : (
            <div className="flex-1">
              <ContractRiskMap
                relationships={analysisResult.relationships}
                clauses={analysisResult.clauses}
                findings={analysisResult.findings}
                onOpenComparisonModal={f => setComparisonModalFinding(f)}
                onSelectClause={clause => {
                  handleSelectClause(clause);
                  setActiveView('split');
                }}
              />
            </div>
          )}
        </main>
      )}

      {/* Deep-dive Side-by-Side Comparison Modal */}
      {comparisonModalFinding && analysisResult && (
        <ClauseComparisonModal
          finding={comparisonModalFinding}
          clauses={analysisResult.clauses}
          onClose={() => setComparisonModalFinding(null)}
        />
      )}

      {/* Structured Executive Audit Report Modal */}
      {isReportOpen && analysisResult && (
        <ReportModal
          result={analysisResult}
          onClose={() => setIsReportOpen(false)}
        />
      )}

      {/* Safe Ruleset Modal */}
      {isRulesetOpen && (
        <RulesetModal onClose={() => setIsRulesetOpen(false)} />
      )}

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-200 bg-white py-4 px-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>ClauseGuard AI — Hackathon MVP · Commercial Legal Risk Screening</span>
          <span>Core rule-based contradiction engine + semantic similarity</span>
        </div>
      </footer>
    </div>
  );
}
