export interface SampleContractPreset {
  id: string;
  name: string;
  type: string;
  description: string;
  text: string;
}

export const DEMO_MASTER_SERVICES_AGREEMENT: SampleContractPreset = {
  id: 'demo-msa-contract',
  name: 'Demo MSA — Tech Services & Licensing Agreement',
  type: 'Master Services Agreement',
  description: 'Built-in benchmark contract containing deliberate contradictions: liability caps vs unlimited indemnity, conflicting notice periods, conflicting IP ownership, and US/Singapore jurisdiction clash.',
  text: `MASTER SERVICES AND TECHNOLOGY AGREEMENT

This Master Services and Technology Agreement ("Agreement") is entered into as of October 1, 2026 ("Effective Date"), by and between Nexus Cloud Technologies Inc., a Delaware corporation with its principal place of business in New York, NY ("Supplier"), and Apex Global Enterprises LLC, a California limited liability company ("Customer").

RECITALS
WHEREAS, Customer desires to engage Supplier to perform cloud implementation, technology integration, and consulting services; and
WHEREAS, Supplier agrees to perform such services subject to the terms and conditions set forth herein.

NOW, THEREFORE, in consideration of the mutual covenants contained herein, the parties agree as follows:

1. DEFINITIONS AND SCOPE OF SERVICES
1.1 "Services" shall mean the software development, architectural consulting, API integration, and cloud deployment services provided by Supplier under applicable Statements of Work ("SOW").
1.2 "Deliverables" means all reports, software code, configurations, documentation, and technical artifacts created or furnished by Supplier in connection with the Services.
1.3 Supplier shall perform all Services with commercially reasonable diligence and in accordance with accepted industry practices.

2. STATEMENTS OF WORK AND CHANGE ORDERS
2.1 Each project shall be governed by an executed SOW describing the scope, timeline, milestones, and fees.
2.2 Any amendment or material variance to an SOW must be agreed upon in writing via an authorized Change Order signed by both parties.

3. FEES AND PAYMENT TERMS
3.1 Customer shall pay Supplier all professional fees and reimbursable expenses specified in the applicable SOW.
3.2 Supplier shall submit monthly invoices. Customer shall pay all undisputed invoice amounts within thirty (30) days from the invoice date (Net 30).
3.3 Past due amounts shall accrue interest at the rate of one and a half percent (1.5%) per month or the maximum rate permitted by law.

4. WARRANTIES AND DISCLAIMERS
4.1 Supplier warrants that the Services will conform in all material respects to the technical specifications outlined in the applicable SOW for a period of ninety (90) days following delivery.
4.2 EXCEPT AS EXPRESSLY STATED HEREIN, ALL SERVICES AND DELIVERABLES ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.

5. INTELLECTUAL PROPERTY AND OWNERSHIP
5.1 Supplier Pre-Existing Rights: Supplier retains sole and exclusive ownership of all right, title, and interest in and to all Supplier background technology, pre-existing proprietary tools, frameworks, core libraries, and generic algorithms.
5.2 Supplier Foreground IP: Supplier shall retain all right, title, and interest, including all patent, copyright, trade secret, and other intellectual property rights, in and to all Deliverables, modifications, enhancements, and software works created or developed hereunder. Customer is granted only a non-exclusive, non-transferable, revocable license to use the Deliverables for its internal business operations.

6. CONFIDENTIAL INFORMATION AND NON-DISCLOSURE
6.1 Each party ("Receiving Party") agrees that all business, technical, operational, and financial information disclosed by the other party ("Disclosing Party") marked confidential or reasonably understood to be confidential shall constitute "Confidential Information".
6.2 The Receiving Party shall protect Disclosing Party's Confidential Information with the same degree of care it uses for its own confidential material, but in no event less than reasonable care.
6.3 The Receiving Party shall not use or disclose any Confidential Information except as necessary to fulfill its obligations under this Agreement.

7. DATA PROTECTION AND GDPR COMPLIANCE
7.1 To the extent Supplier processes personal data originating within the European Economic Area (EEA) or subject to the European Union General Data Protection Regulation (Regulation EU 2016/679 - "GDPR"), Supplier shall act solely as a Data Processor.
7.2 Supplier shall implement appropriate technical and organizational security measures to protect Customer Personal Data against accidental loss, unauthorized disclosure, or unlawful destruction.
7.3 Each party represents that its processing of California resident consumer data complies with the California Consumer Privacy Act (CCPA).

8. INDEMNIFICATION OBLIGATIONS
8.1 Broad Supplier Indemnity: Supplier shall defend, indemnify, and hold harmless Customer, its parent companies, subsidiaries, directors, officers, employees, and agents from and against any and all claims, demands, liabilities, damages, losses, costs, and expenses (including reasonable attorneys' fees and legal costs) arising out of or resulting from: (a) any infringement or misappropriation of any third-party intellectual property rights; (b) any breach of confidentiality or data privacy obligations; (c) any gross negligence, intentional misconduct, or bodily injury caused by Supplier personnel; or (d) any breach of Supplier's statutory obligations.
8.2 Supplier's defense and indemnification obligations under this Section 8 are absolute, primary, and without limitation as to monetary liability.

9. TAXES AND EXPENSES
9.1 Customer shall be responsible for all applicable sales, use, excise, and value-added taxes arising from the purchase of Services, excluding taxes based on Supplier's net income.
9.2 Reimbursable travel expenses must be pre-approved in writing by Customer.

10. LIMITATION OF LIABILITY
10.1 IN NO EVENT SHALL EITHER PARTY BE LIABLE UNDER THIS AGREEMENT OR UNDER ANY SOW FOR ANY INDIRECT, INCIDENTAL, CONSEQUENTIAL, SPECIAL, PUNITIVE, OR EXEMPLARY DAMAGES, INCLUDING LOSS OF REVENUE, LOSS OF PROFITS, LOSS OF DATA, OR LOSS OF BUSINESS REPUTATION, REGARDLESS OF THE THEORY OF LIABILITY.
10.2 AGGREGATE LIABILITY CAP: NOTWITHSTANDING ANYTHING TO THE CONTRARY IN THIS AGREEMENT, AN SOW, OR AN ATTACHMENT, THE TOTAL AGGREGATE LIABILITY OF EITHER PARTY ARISING OUT OF OR RELATING TO THIS AGREEMENT, WHETHER IN CONTRACT, TORT (INCLUDING NEGLIGENCE), INDEMNITY, OR OTHERWISE, SHALL NOT EXCEED FIFTY THOUSAND U.S. DOLLARS ($50,000).

11. WORK PRODUCT AND CUSTOMER OWNERSHIP ASSIGNMENT
11.1 All Deliverables, documentation, custom source code, software modules, architectural schematics, and related inventions developed under this Agreement shall constitute "work made for hire" for Customer under United States copyright law.
11.2 To the extent any Deliverable or invention does not qualify as a work made for hire, Supplier hereby unconditionally and irrevocably assigns, transfers, and conveys to Customer all right, title, and interest throughout the world in and to such Deliverables, including all copyrights, patents, patent disclosures, trade secrets, and proprietary rights. Supplier shall have no ongoing ownership or licensing interest therein.

12. FORCE MAJEURE
12.1 Neither party shall be liable for delay or failure in performance resulting from causes beyond its reasonable control, including acts of God, strikes, labor disputes, wars, terrorism, riots, embargoes, fire, earthquake, or severe weather conditions.
12.2 The affected party shall promptly notify the other party and use diligent efforts to resume performance as soon as practicable.

13. TERMINATION FOR CONVENIENCE
13.1 Customer may terminate this Agreement or any individual SOW for any reason or no reason upon thirty (30) days' prior written notice to Supplier.
13.2 Upon receipt of notice under this Section 13, Supplier shall immediately cease all billable work and Customer shall pay for all Services completed up to the effective termination date.

14. TERMINATION FOR CAUSE
14.1 Either party may terminate this Agreement immediately upon written notice if the other party commits a material breach of this Agreement and fails to cure such breach within fifteen (15) business days after receipt of written notice detailing the breach.
14.2 Either party may terminate immediately if the other party ceases business operations, files for bankruptcy, or becomes insolvent.

15. DISPUTE RESOLUTION AND ARBITRATION
15.1 Any dispute, controversy, or claim arising out of, relating to, or in connection with this Agreement, including any question regarding its existence, validity, or termination, shall be referred to and finally resolved by binding arbitration administered by the Singapore International Arbitration Centre ("SIAC") in accordance with the SIAC Arbitration Rules in force at the time of commencement.
15.2 The seat and legal venue of the arbitration shall be Singapore. The tribunal shall consist of three (3) arbitrators. The language of the arbitration proceedings shall be English. The arbitral award shall be final and enforceable in any court of competent jurisdiction.

16. CONTRACT DURATION AND NOTICE REQUIREMENTS
16.1 This Agreement shall commence on the Effective Date and continue for an initial term of two (2) years, unless terminated earlier in accordance with the provisions herein.
16.2 Either party may terminate this Agreement at will by serving at least sixty (60) days' prior written notice upon the non-terminating party, during which period both parties shall continue their regular operational commitments.

17. CONFIDENTIALITY SURVIVAL PERIOD
17.1 All obligations of non-disclosure and confidentiality set forth in Section 6 shall survive the expiration or termination of this Agreement for a period of exactly one (1) year from the date of termination, after which the Receiving Party shall have no further obligation to maintain the confidentiality of any disclosed materials.

18. RETURN OF MATERIALS AND WIND-DOWN
18.1 Within fourteen (14) days following termination of this Agreement, each party shall securely delete or return all documents, equipment, and tangible property belonging to the other party.
18.2 Upon request, an executive officer shall certify in writing that all electronic copies of Customer Data have been permanently sanitized.

19. GOVERNING LAW AND EXCLUSIVE JUDICIAL FORUM
19.1 This Agreement, and all claims or causes of action (whether in contract, tort, or statute) that may be based upon, arise out of, or relate to this Agreement, shall be governed by, and enforced in accordance with, the internal laws of the State of New York, United States, without regard to conflict of law principles.
19.2 The parties hereby irrevocably and unconditionally submit to the exclusive personal and subject-matter jurisdiction of the State and Federal Courts located in New York County, New York, for any action or proceeding arising out of or relating to this Agreement, and each party waives any defense of inconvenient forum.

20. ASSIGNMENT AND SUBCONTRACTING
20.1 Supplier shall not assign, delegate, or transfer this Agreement, or any of its rights or duties hereunder, without the prior express written consent of Customer.
20.2 Customer may freely assign this Agreement to an affiliate or in connection with a merger, reorganization, or sale of substantially all its assets.

21. MISCELLANEOUS PROVISIONS
21.1 Severability: If any term or provision of this Agreement is held invalid, illegal, or unenforceable, the validity of the remaining provisions shall not in any way be affected or impaired.
21.2 Entire Agreement: This Agreement, together with all executed SOWs, constitutes the entire understanding between the parties and supersedes all prior negotiations, representations, or agreements, whether oral or written.
21.3 No Waiver: No failure or delay by either party in exercising any right or remedy shall operate as a waiver thereof.
`
};

export const SAMPLE_NDA_CONTRACT: SampleContractPreset = {
  id: 'sample-nda',
  name: 'Sample Mutual Non-Disclosure Agreement',
  type: 'Non-Disclosure Agreement',
  description: 'Bilateral NDA featuring survival mismatch (1 year vs 5 years) and New York vs London governing law conflicts.',
  text: `MUTUAL NON-DISCLOSURE AGREEMENT

This Mutual Non-Disclosure Agreement ("Agreement") is dated as of September 15, 2026, between Vertex Systems LLC ("Party A") and Horizon Capital Partners ("Party B").

1. PURPOSE
The parties wish to explore a potential strategic partnership or joint investment transaction ("Purpose").

2. CONFIDENTIAL INFORMATION
"Confidential Information" means proprietary technical, financial, customer, and product data disclosed by one party to the other.

3. EXCLUSIONS FROM CONFIDENTIALITY
Confidential Information does not include information that: (a) is or becomes publicly known through no breach; (b) was already in Receiving Party's possession prior to disclosure; or (c) is independently developed without reference to the Disclosing Party's data.

4. NON-DISCLOSURE OBLIGATIONS
Each party agrees to hold the other's Confidential Information in strict confidence and use it solely for the Purpose.

5. SURVIVAL CLAUSE A
The confidentiality obligations under this Agreement shall expire exactly one (1) year following the date of disclosure.

6. SURVIVAL CLAUSE B
Notwithstanding Section 5, all obligations of non-disclosure and non-use regarding proprietary source code and trade secrets shall survive for five (5) years following the termination of this Agreement.

7. GOVERNING LAW AND VENUE
This Agreement shall be governed by the laws of the State of Delaware, USA, and exclusive jurisdiction shall reside in Wilmington, Delaware.

8. DISPUTE RESOLUTION
In the event of any breach, the parties agree that all disputes shall be resolved in the High Court of Justice in London, United Kingdom, under English legal doctrine.
`
};

export const SAMPLE_PRESETS: SampleContractPreset[] = [
  DEMO_MASTER_SERVICES_AGREEMENT,
  SAMPLE_NDA_CONTRACT
];
