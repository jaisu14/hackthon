export type SeverityLevel = 'Critical' | 'High' | 'Medium' | 'Low';

export type ClauseCategory =
  | 'Confidentiality'
  | 'Indemnity'
  | 'Limitation of Liability'
  | 'Termination'
  | 'Payment'
  | 'Intellectual Property'
  | 'Data Protection'
  | 'Governing Law'
  | 'Dispute Resolution'
  | 'Warranty'
  | 'Force Majeure'
  | 'Insurance'
  | 'Assignment'
  | 'Non-Compete'
  | 'General Provisions';

export interface Clause {
  id: string;
  clauseNumber: string; // e.g. "1.1", "Clause 4", "Section 8"
  numericIndex: number;
  title: string;
  text: string;
  pageNumber?: number;
  category: ClauseCategory;
  categoryConfidence: number; // 0 - 100
  keyEntities: {
    durations?: string[];
    monetaryValues?: string[];
    jurisdictions?: string[];
    noticePeriods?: string[];
  };
}

export type FindingType =
  | 'Contradiction'
  | 'Missing Clause'
  | 'Risky Clause'
  | 'Jurisdiction Conflict'
  | 'Ambiguity';

export interface ContradictionDetail {
  clauseAId: string;
  clauseANumber: string;
  clauseATitle: string;
  clauseASnippet: string;

  clauseBId: string;
  clauseBNumber: string;
  clauseBTitle: string;
  clauseBSnippet: string;

  conflictDimension:
    | 'Liability vs Indemnity'
    | 'Termination Notice'
    | 'Jurisdiction & Venue'
    | 'IP Ownership'
    | 'Survival Duration'
    | 'Payment Terms'
    | 'Warranty Disclaimer';
  explanation: string;
}

export interface RiskFinding {
  id: string;
  severity: SeverityLevel;
  confidence: number; // 0 - 100
  type: FindingType;
  title: string;
  explanation: string;
  affectedClauseNumbers: string[];
  affectedClauseIds: string[];
  recommendedAction: string;
  contradiction?: ContradictionDetail;
  evidenceQuotes?: string[];
  missingClauseName?: string;
  jurisdictionsDetected?: string[];
}

export interface JurisdictionMention {
  name: string;
  clauseId: string;
  clauseNumber: string;
  context: string;
}

export interface JurisdictionReport {
  detectedJurisdictions: string[];
  mentions: JurisdictionMention[];
  hasConflict: boolean;
  notes: string[];
}

export interface ContractRelationship {
  id: string;
  sourceClauseId: string;
  sourceClauseNumber: string;
  sourceTitle: string;
  targetClauseId: string;
  targetClauseNumber: string;
  targetTitle: string;
  relationshipType: 'CONTRADICTS' | 'CONFLICTS' | 'QUALIFIES' | 'REFERENCES';
  severity: SeverityLevel;
  description: string;
}

export interface AnalysisSummary {
  overallRisk: SeverityLevel;
  totalClauses: number;
  totalRisks: number;
  contradictionsCount: number;
  missingClausesCount: number;
  jurisdictionIssuesCount: number;
  contractTypeDetected: string;
  estimatedPages: number;
  criticalCount: number;
  highCount: number;
  mediumCount: number;
  lowCount: number;
}

export interface AnalysisResult {
  documentName: string;
  documentText: string;
  clauses: Clause[];
  findings: RiskFinding[];
  relationships: ContractRelationship[];
  jurisdictionReport: JurisdictionReport;
  summary: AnalysisSummary;
  safeRulesetResults: {
    expectedClauses: string[];
    foundClauses: string[];
    missingClauses: string[];
  };
  analyzedAt: string;
}
