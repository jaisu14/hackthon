import React, { useState } from 'react';
import { ContractRelationship, Clause, RiskFinding } from '../types/contract';
import { GitCompare, ArrowRight, ShieldAlert, AlertTriangle, Layers, Filter, ExternalLink } from 'lucide-react';

interface ContractRiskMapProps {
  relationships: ContractRelationship[];
  clauses: Clause[];
  findings: RiskFinding[];
  onOpenComparisonModal: (finding: RiskFinding) => void;
  onSelectClause: (clause: Clause) => void;
}

export const ContractRiskMap: React.FC<ContractRiskMapProps> = ({
  relationships,
  clauses,
  findings,
  onOpenComparisonModal,
  onSelectClause
}) => {
  const [filterType, setFilterType] = useState<'ALL' | 'CONTRADICTS' | 'CONFLICTS' | 'QUALIFIES'>('ALL');

  const filteredRelationships = relationships.filter(r => {
    if (filterType === 'ALL') return true;
    return r.relationshipType === filterType;
  });

  const getRelationshipBadge = (type: ContractRelationship['relationshipType']) => {
    switch (type) {
      case 'CONTRADICTS':
        return 'bg-rose-100 text-rose-800 border-rose-300 font-bold';
      case 'CONFLICTS':
        return 'bg-amber-100 text-amber-800 border-amber-300 font-bold';
      case 'QUALIFIES':
        return 'bg-blue-100 text-blue-800 border-blue-300';
      case 'REFERENCES':
        return 'bg-slate-100 text-slate-700 border-slate-300';
    }
  };

  // Find corresponding finding for a relationship
  const findFindingForRelationship = (rel: ContractRelationship) => {
    return findings.find(f =>
      f.affectedClauseIds.includes(rel.sourceClauseId) &&
      f.affectedClauseIds.includes(rel.targetClauseId)
    );
  };

  // Group clauses by thematic clusters
  const clusters = [
    {
      name: 'Liability & Indemnity Exposure',
      categories: ['Limitation of Liability', 'Indemnity'],
      description: 'Potential collisions between unlimited indemnity provisions and aggregate monetary caps'
    },
    {
      name: 'Operational Exit & Notice',
      categories: ['Termination'],
      description: 'Notice timelines (30 days vs 60 days) and at-will termination mechanics'
    },
    {
      name: 'Governance, Forum & Arbitration',
      categories: ['Governing Law', 'Dispute Resolution'],
      description: 'Choice of law doctrines and exclusive court venue vs binding foreign arbitral seats'
    },
    {
      name: 'Intellectual Property & Deliverables',
      categories: ['Intellectual Property'],
      description: 'Background IP reservations vs customer work-for-hire assignment covenants'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Overview header */}
      <div className="bg-white rounded-lg border border-slate-200 p-5 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-slate-800" />
            <h2 className="text-base font-semibold text-slate-900">
              Contract Risk & Contradiction Map
            </h2>
          </div>
          <p className="text-xs text-slate-600 mt-1 max-w-2xl">
            Visual relationship network linking interconnected, qualifying, and directly contradictory clauses across the agreement.
          </p>
        </div>

        {/* Filter buttons */}
        <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-md text-xs">
          <button
            type="button"
            onClick={() => setFilterType('ALL')}
            className={`px-3 py-1 rounded-sm font-medium transition-colors ${
              filterType === 'ALL' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            All Links ({relationships.length})
          </button>
          <button
            type="button"
            onClick={() => setFilterType('CONTRADICTS')}
            className={`px-3 py-1 rounded-sm font-medium transition-colors flex items-center gap-1 text-rose-700 ${
              filterType === 'CONTRADICTS' ? 'bg-white text-rose-900 shadow-2xs' : 'hover:text-rose-900'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5 text-rose-600" />
            Contradictions ({relationships.filter(r => r.relationshipType === 'CONTRADICTS').length})
          </button>
          <button
            type="button"
            onClick={() => setFilterType('CONFLICTS')}
            className={`px-3 py-1 rounded-sm font-medium transition-colors text-amber-700 ${
              filterType === 'CONFLICTS' ? 'bg-white text-amber-900 shadow-2xs' : 'hover:text-amber-900'
            }`}
          >
            Jurisdiction Conflicts ({relationships.filter(r => r.relationshipType === 'CONFLICTS').length})
          </button>
        </div>
      </div>

      {/* Main Relationships List / Cards */}
      <div className="space-y-4">
        <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
          Detected Clause Relationships ({filteredRelationships.length})
        </h3>

        {filteredRelationships.length === 0 ? (
          <div className="bg-white p-8 rounded-lg border border-slate-200 text-center text-xs text-slate-500">
            No relationships match the selected filter.
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4">
            {filteredRelationships.map(rel => {
              const sourceClause = clauses.find(c => c.id === rel.sourceClauseId);
              const targetClause = clauses.find(c => c.id === rel.targetClauseId);
              const associatedFinding = findFindingForRelationship(rel);

              return (
                <div
                  key={rel.id}
                  className={`bg-white rounded-lg border p-4 sm:p-5 transition-all shadow-xs ${
                    rel.severity === 'Critical'
                      ? 'border-rose-200 hover:border-rose-300'
                      : rel.severity === 'High'
                      ? 'border-amber-200 hover:border-amber-300'
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4">
                    {/* Source Node */}
                    <div
                      onClick={() => sourceClause && onSelectClause(sourceClause)}
                      className="flex-1 bg-slate-50 p-3 rounded-md border border-slate-200 cursor-pointer hover:bg-slate-100 transition-colors"
                    >
                      <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1">
                        <span className="font-mono font-bold text-slate-900 bg-white px-1.5 py-0.5 rounded-xs border border-slate-200">
                          {rel.sourceClauseNumber}
                        </span>
                        <span>{sourceClause?.category}</span>
                      </div>
                      <h4 className="text-xs font-bold text-slate-900">
                        {rel.sourceTitle}
                      </h4>
                      <p className="text-[11px] text-slate-600 line-clamp-2 mt-1">
                        {sourceClause?.text}
                      </p>
                    </div>

                    {/* Middle Connector Pill */}
                    <div className="flex flex-col items-center justify-center shrink-0 px-2 text-center">
                      <span
                        className={`text-[10px] uppercase px-2.5 py-1 rounded-sm border mb-1 flex items-center gap-1 ${getRelationshipBadge(
                          rel.relationshipType
                        )}`}
                      >
                        {rel.relationshipType === 'CONTRADICTS' && (
                          <ShieldAlert className="w-3 h-3 text-rose-700" />
                        )}
                        {rel.relationshipType === 'CONFLICTS' && (
                          <AlertTriangle className="w-3 h-3 text-amber-700" />
                        )}
                        <span>{rel.relationshipType}</span>
                      </span>

                      <p className="text-[11px] text-slate-500 max-w-xs font-medium">
                        {rel.description}
                      </p>

                      {associatedFinding && (
                        <button
                          type="button"
                          onClick={() => onOpenComparisonModal(associatedFinding)}
                          className="mt-1 text-[11px] text-blue-700 font-semibold hover:underline flex items-center gap-1"
                        >
                          Deep dive comparison <ExternalLink className="w-3 h-3" />
                        </button>
                      )}
                    </div>

                    {/* Target Node */}
                    <div
                      onClick={() => targetClause && onSelectClause(targetClause)}
                      className="flex-1 bg-slate-50 p-3 rounded-md border border-slate-200 cursor-pointer hover:bg-slate-100 transition-colors"
                    >
                      <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1">
                        <span className="font-mono font-bold text-slate-900 bg-white px-1.5 py-0.5 rounded-xs border border-slate-200">
                          {rel.targetClauseNumber}
                        </span>
                        <span>{targetClause?.category}</span>
                      </div>
                      <h4 className="text-xs font-bold text-slate-900">
                        {rel.targetTitle}
                      </h4>
                      <p className="text-[11px] text-slate-600 line-clamp-2 mt-1">
                        {targetClause?.text}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Domain Risk Clusters */}
      <div className="bg-white rounded-lg border border-slate-200 p-5 space-y-4">
        <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
          Contract Governance & Risk Clusters
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {clusters.map((cluster, i) => {
            const clusterClauses = clauses.filter(c => cluster.categories.includes(c.category));
            return (
              <div key={i} className="p-3 bg-slate-50 rounded-md border border-slate-200">
                <span className="text-xs font-bold text-slate-900 block">
                  {cluster.name}
                </span>
                <p className="text-[11px] text-slate-500 mt-1">
                  {cluster.description}
                </p>
                <div className="mt-3 pt-2 border-t border-slate-200 flex items-center justify-between text-[11px]">
                  <span className="text-slate-500">Clauses present:</span>
                  <span className="font-mono font-bold text-slate-800">
                    {clusterClauses.length}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
