import React, { useState, useRef } from 'react';
import { UploadCloud, FileText, CheckCircle2, AlertCircle, ArrowRight, Sparkles, Layers, ShieldCheck } from 'lucide-react';
import { SAMPLE_PRESETS } from '../data/sampleContracts';

interface HeroUploadProps {
  onAnalyzeText: (text: string, docName: string) => void;
  onAnalyzeFile: (file: File) => void;
  onLoadDemo: (presetId?: string) => void;
  isProcessing: boolean;
  processingStep: string;
}

export const HeroUpload: React.FC<HeroUploadProps> = ({
  onAnalyzeText,
  onAnalyzeFile,
  onLoadDemo,
  isProcessing,
  processingStep
}) => {
  const [dragActive, setDragActive] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [activeTab, setActiveTab] = useState<'upload' | 'paste'>('upload');
  const [pastedText, setPastedText] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      setSelectedFile(file);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0]);
    }
  };

  const handleAnalyzeClick = () => {
    if (activeTab === 'upload' && selectedFile) {
      onAnalyzeFile(selectedFile);
    } else if (activeTab === 'paste' && pastedText.trim()) {
      onAnalyzeText(pastedText.trim(), 'Pasted Agreement Text');
    }
  };

  return (
    <div className="bg-white border-b border-slate-200">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-10 sm:py-12">
        {/* Title & Subtitle */}
        <div className="text-center max-w-3xl mx-auto mb-8">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-100 text-slate-700 text-xs font-medium mb-3">
            <ShieldCheck className="w-3.5 h-3.5 text-slate-800" />
            Deterministic Safe-Contract & Contradiction Verification
          </div>
          <h1 className="text-3xl sm:text-4xl font-semibold tracking-tight text-slate-900 leading-tight">
            ClauseGuard AI
          </h1>
          <p className="mt-2 text-base text-slate-600 max-w-2xl mx-auto">
            Detect hidden contract risks and contradictions before they become problems.
          </p>
          <div className="mt-2 text-xs text-slate-500 flex items-center justify-center gap-2">
            <span>Missing clauses</span>
            <span aria-hidden="true">·</span>
            <span>Liability vs Indemnity traps</span>
            <span aria-hidden="true">·</span>
            <span>Notice period conflicts</span>
            <span aria-hidden="true">·</span>
            <span>Cross-jurisdiction clashes</span>
          </div>
        </div>

        {/* Upload Container */}
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 sm:p-6 shadow-xs">
          {/* Tabs */}
          <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
            <div className="flex items-center gap-1 bg-slate-200/70 p-1 rounded-md">
              <button
                type="button"
                onClick={() => setActiveTab('upload')}
                className={`px-3 py-1 text-xs font-medium rounded-sm transition-colors ${
                  activeTab === 'upload' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Upload PDF / DOCX
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('paste')}
                className={`px-3 py-1 text-xs font-medium rounded-sm transition-colors ${
                  activeTab === 'paste' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Direct Text Paste
              </button>
            </div>

            {/* Demo Presets dropdown / button */}
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500 hidden sm:inline">Try benchmark:</span>
              <button
                type="button"
                onClick={() => onLoadDemo()}
                className="px-2.5 py-1 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-md hover:bg-slate-100 transition-colors flex items-center gap-1.5 shadow-2xs"
              >
                <Sparkles className="w-3 h-3 text-amber-600" />
                Demo Contract (MSA)
              </button>
            </div>
          </div>

          {/* Upload Area */}
          {activeTab === 'upload' ? (
            <div>
              <div
                onDragEnter={handleDrag}
                onDragLeave={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className={`border-2 border-dashed rounded-lg p-6 sm:p-8 text-center cursor-pointer transition-all ${
                  dragActive
                    ? 'border-slate-800 bg-slate-100'
                    : 'border-slate-300 hover:border-slate-400 bg-white'
                }`}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".pdf,.docx,.doc,.txt,.md"
                  onChange={handleFileChange}
                  className="hidden"
                />

                <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-3 text-slate-700">
                  <UploadCloud className="w-6 h-6" />
                </div>

                {selectedFile ? (
                  <div>
                    <p className="text-sm font-semibold text-slate-900 flex items-center justify-center gap-1.5">
                      <FileText className="w-4 h-4 text-slate-600" />
                      {selectedFile.name}
                    </p>
                    <p className="text-xs text-slate-500 mt-1">
                      {(selectedFile.size / 1024).toFixed(1)} KB · Ready for structural extraction
                    </p>
                  </div>
                ) : (
                  <div>
                    <p className="text-sm font-medium text-slate-800">
                      Drag and drop your contract here, or <span className="text-blue-700 underline font-semibold">browse</span>
                    </p>
                    <p className="text-xs text-slate-500 mt-1">
                      Supports PDF, DOCX, and TXT (Max 25MB)
                    </p>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div>
              <textarea
                value={pastedText}
                onChange={e => setPastedText(e.target.value)}
                placeholder="Paste contract text, clauses, or agreement clauses here..."
                rows={7}
                className="w-full text-xs font-mono p-3 bg-white border border-slate-300 rounded-md focus:outline-hidden focus:ring-1 focus:ring-slate-800 focus:border-slate-800"
              />
              <p className="text-[11px] text-slate-500 mt-1 flex justify-between">
                <span>Direct analysis parses numbered sections and headings automatically.</span>
                <span>{pastedText.length} characters</span>
              </p>
            </div>
          )}

          {/* Action Button & Processing indicator */}
          <div className="mt-4 flex flex-col sm:flex-row items-center justify-between gap-3 pt-3 border-t border-slate-200">
            <div className="text-xs text-slate-500 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              Rule-based NLP & Semantic Engine ready
            </div>

            <div className="flex items-center gap-3 w-full sm:w-auto">
              <button
                type="button"
                disabled={isProcessing || (activeTab === 'upload' && !selectedFile) || (activeTab === 'paste' && !pastedText.trim())}
                onClick={handleAnalyzeClick}
                className={`w-full sm:w-auto px-5 py-2 rounded-md text-xs font-semibold text-white transition-all flex items-center justify-center gap-2 shadow-xs ${
                  isProcessing || (activeTab === 'upload' && !selectedFile) || (activeTab === 'paste' && !pastedText.trim())
                    ? 'bg-slate-400 cursor-not-allowed'
                    : 'bg-slate-900 hover:bg-slate-800 active:scale-98'
                }`}
              >
                {isProcessing ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>{processingStep || 'Analyzing Contract...'}</span>
                  </>
                ) : (
                  <>
                    <span>Analyze Contract</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
