import React from 'react';
import { RiskFinding, Clause } from '../types/contract';
import { X, GitCompare, AlertTriangle, ShieldAlert, ArrowRight, CheckCircle2 } from 'lucide-react';

interface ClauseComparisonModalProps {
  finding: RiskFinding | null;
  clauses: Clause[];
  onClose: () => void;
}

export const ClauseComparisonModal: React.FC<ClauseComparisonModalProps> = ({
  finding,
  clauses,
  onClose
}) => {
  if (!finding || !finding.contradiction) return null;

  const contra = finding.contradiction;
  const clauseA = clauses.find(c => c.id === contra.clauseAId);
  const clauseB = clauses.find(c => c.id === contra.clauseBId);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-lg shadow-xl border border-slate-200 max-w-4xl w-full max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-md bg-rose-100 flex items-center justify-center text-rose-700">
              <GitCompare className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-rose-700 bg-rose-50 px-2 py-0.5 rounded-sm border border-rose-200">
                  {finding.severity} Contradiction
                </span>
                <span className="text-xs font-medium text-slate-500">
                  {contra.conflictDimension}
                </span>
              </div>
              <h3 className="text-sm font-bold text-slate-900 mt-0.5">
                {finding.title}
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1 rounded-md transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Explanation Banner */}
          <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200 text-xs text-slate-700">
            <p className="font-semibold text-slate-900 mb-1">Conflict Summary:</p>
            <p>{contra.explanation}</p>
          </div>

          {/* Side-by-side Clauses View */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Clause A */}
            <div className="border border-slate-300 rounded-lg p-4 bg-white flex flex-col">
              <div className="flex items-center justify-between border-b border-slate-200 pb-2 mb-3">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded-xs">
                    {contra.clauseANumber}
                  </span>
                  <span className="text-xs font-semibold text-slate-900">
                    {contra.clauseATitle}
                  </span>
                </div>
                <span className="text-[11px] text-slate-500">{clauseA?.category}</span>
              </div>

              <div className="bg-amber-50/50 border border-amber-200 rounded-md p-2.5 mb-3 text-xs font-serif italic text-amber-950">
                <span className="font-sans font-bold text-[10px] text-amber-800 uppercase tracking-wider block mb-1">
                  Key Conflicting Text:
                </span>
                "{contra.clauseASnippet}"
              </div>

              <div className="text-xs text-slate-700 whitespace-pre-wrap leading-relaxed flex-1 font-sans">
                {clauseA?.text || 'Clause text not available.'}
              </div>
            </div>

            {/* Clause B */}
            <div className="border border-rose-300 rounded-lg p-4 bg-rose-50/10 flex flex-col">
              <div className="flex items-center justify-between border-b border-rose-200 pb-2 mb-3">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs font-bold text-rose-900 bg-rose-100 px-2 py-0.5 rounded-xs">
                    {contra.clauseBNumber}
                  </span>
                  <span className="text-xs font-semibold text-slate-900">
                    {contra.clauseBTitle}
                  </span>
                </div>
                <span className="text-[11px] text-slate-500">{clauseB?.category}</span>
              </div>

              <div className="bg-rose-50 border border-rose-200 rounded-md p-2.5 mb-3 text-xs font-serif italic text-rose-950">
                <span className="font-sans font-bold text-[10px] text-rose-800 uppercase tracking-wider block mb-1">
                  Key Conflicting Text:
                </span>
                "{contra.clauseBSnippet}"
              </div>

              <div className="text-xs text-slate-700 whitespace-pre-wrap leading-relaxed flex-1 font-sans">
                {clauseB?.text || 'Clause text not available.'}
              </div>
            </div>
          </div>

          {/* Action Recommendation */}
          <div className="p-4 rounded-lg bg-blue-50 border border-blue-200">
            <h4 className="text-xs font-bold text-blue-900 uppercase tracking-wider mb-1 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-blue-700" />
              Recommended Legal Harmonization
            </h4>
            <p className="text-xs text-blue-900 leading-relaxed">
              {finding.recommendedAction}
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-md hover:bg-slate-100 transition-colors"
          >
            Close View
          </button>
        </div>
      </div>
    </div>
  );
};
