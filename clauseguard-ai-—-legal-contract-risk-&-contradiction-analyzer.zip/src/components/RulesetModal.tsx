import React from 'react';
import rulesData from '../engine/rules.json';
import { X, BookOpen, ShieldCheck, CheckCircle2, AlertTriangle } from 'lucide-react';

interface RulesetModalProps {
  onClose: () => void;
}

export const RulesetModal: React.FC<RulesetModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-lg shadow-xl border border-slate-200 max-w-3xl w-full max-h-[85vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-md bg-slate-900 flex items-center justify-center text-white">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Predefined Safe-Contract Ruleset
              </h3>
              <p className="text-[11px] text-slate-500">
                Rule definitions, expected standard clauses, and risk heuristics
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1.5 rounded-md transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-xs text-slate-700">
          <div className="p-3 bg-blue-50 border border-blue-200 rounded-md text-blue-950">
            <span className="font-semibold block mb-0.5">Deterministic Contract Architecture:</span>
            ClauseGuard AI evaluates contracts against verified corporate legal standards. The system does not depend on unpredictable generative hallucinations for core risk triage; it uses deterministic semantic distance and legal contradiction rules.
          </div>

          <div>
            <h4 className="font-bold text-slate-900 uppercase tracking-wider mb-2">
              1. Expected Standard Clauses by Contract Archetype
            </h4>
            <div className="space-y-3">
              {Object.entries(rulesData.contractTypes).map(([type, spec]) => (
                <div key={type} className="border border-slate-200 rounded-md p-3 bg-slate-50">
                  <h5 className="font-bold text-slate-900 text-xs mb-1.5">{type}</h5>
                  <div className="mb-2">
                    <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">
                      Required Clauses:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {spec.requiredClauses.map((rc, idx) => (
                        <span key={idx} className="bg-white border border-slate-200 px-2 py-0.5 rounded-xs text-[11px] font-medium text-slate-800">
                          {rc}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
                      Recommended Additional:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {spec.recommendedClauses.map((rc, idx) => (
                        <span key={idx} className="bg-slate-100 text-slate-600 px-2 py-0.5 rounded-xs text-[11px]">
                          {rc}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-bold text-slate-900 uppercase tracking-wider mb-2">
              2. Core Contradiction Verification Matrix
            </h4>
            <div className="border border-slate-200 rounded-md overflow-hidden">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-100 text-slate-700 border-b border-slate-200">
                    <th className="p-2.5 font-bold">Conflict Dimension</th>
                    <th className="p-2.5 font-bold">Severity</th>
                    <th className="p-2.5 font-bold">Detection Heuristic</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  <tr>
                    <td className="p-2.5 font-medium text-slate-900">Liability vs Indemnity</td>
                    <td className="p-2.5 text-rose-700 font-bold">Critical</td>
                    <td className="p-2.5 text-slate-600">Unlimited indemnity obligations without carve-out paired with fixed aggregate dollar liability cap.</td>
                  </tr>
                  <tr>
                    <td className="p-2.5 font-medium text-slate-900">Termination Notice Mismatch</td>
                    <td className="p-2.5 text-amber-800 font-bold">High</td>
                    <td className="p-2.5 text-slate-600">Conflicting convenience notice durations (e.g. 30 days vs 60 days).</td>
                  </tr>
                  <tr>
                    <td className="p-2.5 font-medium text-slate-900">Governing Law vs Foreign Forum</td>
                    <td className="p-2.5 text-rose-700 font-bold">Critical / High</td>
                    <td className="p-2.5 text-slate-600">Exclusive state/federal court jurisdiction colliding with mandatory foreign arbitration seat (e.g. New York vs Singapore SIAC).</td>
                  </tr>
                  <tr>
                    <td className="p-2.5 font-medium text-slate-900">IP Ownership Inconsistency</td>
                    <td className="p-2.5 text-rose-700 font-bold">Critical</td>
                    <td className="p-2.5 text-slate-600">Supplier foreground IP retention clause vs Customer work-for-hire assignment clause.</td>
                  </tr>
                  <tr>
                    <td className="p-2.5 font-medium text-slate-900">Survival Period Divergence</td>
                    <td className="p-2.5 text-blue-800 font-bold">Medium</td>
                    <td className="p-2.5 text-slate-600">Discrepancy in confidentiality survival duration (e.g. 1 year vs 5 years).</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-md hover:bg-slate-100 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
