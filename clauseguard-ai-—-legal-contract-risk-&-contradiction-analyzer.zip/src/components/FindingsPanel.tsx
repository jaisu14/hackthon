import React, { useState } from 'react';
import { RiskFinding, SeverityLevel, FindingType } from '../types/contract';
import {
  ShieldAlert,
  AlertTriangle,
  GitCompare,
  FileQuestion,
  Globe2,
  ChevronRight,
  ExternalLink,
  CheckCircle2,
  Sparkles
} from 'lucide-react';

interface FindingsPanelProps {
  findings: RiskFinding[];
  selectedFinding: RiskFinding | null;
  onSelectFinding: (finding: RiskFinding) => void;
  onOpenComparisonModal: (finding: RiskFinding) => void;
  activeTypeFilter?: string;
  onSetTypeFilter?: (type: string) => void;
}

export const FindingsPanel: React.FC<FindingsPanelProps> = ({
  findings,
  selectedFinding,
  onSelectFinding,
  onOpenComparisonModal,
  activeTypeFilter = 'all',
  onSetTypeFilter
}) => {
  const [severityFilter, setSeverityFilter] = useState<'All' | SeverityLevel>('All');

  // Filter findings
  const filteredFindings = findings.filter(f => {
    const matchesSev = severityFilter === 'All' || f.severity === severityFilter;
    const matchesType =
      !activeTypeFilter ||
      activeTypeFilter === 'all' ||
      f.type === activeTypeFilter;
    return matchesSev && matchesType;
  });

  const getSeverityBadge = (sev: SeverityLevel) => {
    switch (sev) {
      case 'Critical':
        return 'text-rose-700 bg-rose-50 border-rose-200';
      case 'High':
        return 'text-amber-800 bg-amber-50 border-amber-200';
      case 'Medium':
        return 'text-blue-800 bg-blue-50 border-blue-200';
      case 'Low':
        return 'text-slate-700 bg-slate-100 border-slate-200';
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-50/50">
      {/* Filters Header */}
      <div className="p-3 border-b border-slate-200 bg-white space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-900 uppercase tracking-wider">
              Risk Findings
            </span>
            <span className="text-xs font-mono font-bold text-slate-700 bg-slate-100 px-2 py-0.5 rounded-sm">
              {filteredFindings.length} / {findings.length}
            </span>
          </div>

          {/* Type filters */}
          {onSetTypeFilter && (
            <div className="flex items-center gap-1 text-[11px]">
              <button
                type="button"
                onClick={() => onSetTypeFilter('all')}
                className={`px-2 py-0.5 rounded-xs transition-colors ${
                  activeTypeFilter === 'all'
                    ? 'bg-slate-900 text-white font-medium'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                All
              </button>
              <button
                type="button"
                onClick={() => onSetTypeFilter('Contradiction')}
                className={`px-2 py-0.5 rounded-xs transition-colors flex items-center gap-1 ${
                  activeTypeFilter === 'Contradiction'
                    ? 'bg-rose-900 text-white font-medium'
                    : 'text-rose-700 hover:text-rose-900'
                }`}
              >
                Contradictions
              </button>
              <button
                type="button"
                onClick={() => onSetTypeFilter('Missing Clause')}
                className={`px-2 py-0.5 rounded-xs transition-colors ${
                  activeTypeFilter === 'Missing Clause'
                    ? 'bg-amber-900 text-white font-medium'
                    : 'text-amber-700 hover:text-amber-900'
                }`}
              >
                Missing
              </button>
            </div>
          )}
        </div>

        {/* Severity Filter Tabs */}
        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-md text-xs">
          {(['All', 'Critical', 'High', 'Medium', 'Low'] as const).map(sev => {
            const count =
              sev === 'All'
                ? findings.length
                : findings.filter(f => f.severity === sev).length;

            return (
              <button
                key={sev}
                type="button"
                onClick={() => setSeverityFilter(sev)}
                className={`flex-1 py-1 text-center font-medium rounded-xs transition-colors ${
                  severityFilter === sev
                    ? 'bg-white text-slate-900 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {sev} <span className="font-mono text-[10px] opacity-70">({count})</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Findings List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {filteredFindings.length === 0 ? (
          <div className="p-8 text-center bg-white border border-slate-200 rounded-lg text-xs text-slate-500">
            No risk findings match the selected filters.
          </div>
        ) : (
          filteredFindings.map(finding => {
            const isSelected = selectedFinding?.id === finding.id;

            return (
              <div
                key={finding.id}
                onClick={() => onSelectFinding(finding)}
                className={`rounded-lg border bg-white p-4 transition-all cursor-pointer relative ${
                  isSelected
                    ? 'border-slate-900 ring-2 ring-slate-900/10 shadow-sm'
                    : finding.severity === 'Critical'
                    ? 'border-rose-200 hover:border-rose-300'
                    : finding.severity === 'High'
                    ? 'border-amber-200 hover:border-amber-300'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                {/* Header: Severity, Type, Confidence */}
                <div className="flex items-center justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[11px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-sm border ${getSeverityBadge(
                        finding.severity
                      )}`}
                    >
                      {finding.severity}
                    </span>

                    <span className="text-[11px] text-slate-500 font-medium">
                      {finding.type}
                    </span>
                  </div>

                  <span className="text-[11px] font-mono tabular-nums text-slate-500">
                    Confidence: {finding.confidence}%
                  </span>
                </div>

                {/* Finding Title */}
                <h4 className="text-xs font-bold text-slate-900 leading-snug">
                  {finding.title}
                </h4>

                {/* Affected Clauses Links */}
                {finding.affectedClauseNumbers.length > 0 && (
                  <div className="mt-1.5 flex items-center gap-1.5 text-xs">
                    <span className="text-slate-500 text-[11px]">Affected:</span>
                    <span className="font-mono font-semibold text-slate-900 bg-slate-100 px-1.5 py-0.5 rounded-xs text-[11px]">
                      {finding.affectedClauseNumbers.join(' ↔ ')}
                    </span>
                  </div>
                )}

                {/* Explanation */}
                <p className="mt-2 text-xs text-slate-600 leading-relaxed">
                  {finding.explanation}
                </p>

                {/* Side-by-side Evidence Box (For Contradictions) */}
                {finding.contradiction && (
                  <div className="mt-3 bg-slate-50 rounded-md border border-slate-200 p-2.5 space-y-2">
                    <div className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider flex items-center justify-between">
                      <span>Conflict Evidence Pair</span>
                      <button
                        type="button"
                        onClick={e => {
                          e.stopPropagation();
                          onOpenComparisonModal(finding);
                        }}
                        className="text-blue-700 hover:underline flex items-center gap-0.5 lowercase font-normal"
                      >
                        Deep dive side-by-side <ExternalLink className="w-2.5 h-2.5" />
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                      <div className="bg-white p-2 rounded-xs border border-slate-200">
                        <span className="font-mono text-[10px] font-bold text-slate-700 block mb-1">
                          {finding.contradiction.clauseANumber}: {finding.contradiction.clauseATitle}
                        </span>
                        <p className="text-[11px] text-slate-700 italic font-serif leading-tight">
                          "{finding.contradiction.clauseASnippet}"
                        </p>
                      </div>

                      <div className="bg-white p-2 rounded-xs border border-rose-200 bg-rose-50/20">
                        <span className="font-mono text-[10px] font-bold text-rose-800 block mb-1">
                          {finding.contradiction.clauseBNumber}: {finding.contradiction.clauseBTitle}
                        </span>
                        <p className="text-[11px] text-rose-900 italic font-serif leading-tight">
                          "{finding.contradiction.clauseBSnippet}"
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Recommended Review Action */}
                <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-start gap-2">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider shrink-0 mt-0.5">
                    Counsel Action:
                  </span>
                  <p className="text-xs text-slate-800 font-medium">
                    {finding.recommendedAction}
                  </p>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
