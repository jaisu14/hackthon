import React from 'react';
import { AnalysisSummary, SeverityLevel } from '../types/contract';
import { ShieldAlert, AlertTriangle, GitCompare, FileQuestion, Globe2, CheckCircle2 } from 'lucide-react';

interface AnalysisSummaryBarProps {
  summary: AnalysisSummary;
  onFilterFindings?: (type: string) => void;
  activeFilter?: string;
}

export const AnalysisSummaryBar: React.FC<AnalysisSummaryBarProps> = ({
  summary,
  onFilterFindings,
  activeFilter
}) => {
  const getSeverityStyle = (sev: SeverityLevel) => {
    switch (sev) {
      case 'Critical':
        return 'text-rose-700 bg-rose-50 border-rose-200';
      case 'High':
        return 'text-amber-800 bg-amber-50 border-amber-200';
      case 'Medium':
        return 'text-blue-800 bg-blue-50 border-blue-200';
      case 'Low':
        return 'text-emerald-800 bg-emerald-50 border-emerald-200';
    }
  };

  return (
    <div className="bg-white border-b border-slate-200 px-4 sm:px-6 py-3.5">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
        {/* Overall Risk Level */}
        <div className="flex items-center gap-3">
          <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">
            Overall Risk:
          </span>
          <div
            className={`px-2.5 py-1 rounded-md text-xs font-bold border uppercase tracking-wider flex items-center gap-1.5 ${getSeverityStyle(
              summary.overallRisk
            )}`}
          >
            {summary.overallRisk === 'Critical' && <ShieldAlert className="w-3.5 h-3.5" />}
            {summary.overallRisk === 'High' && <AlertTriangle className="w-3.5 h-3.5" />}
            {summary.overallRisk === 'Medium' && <AlertTriangle className="w-3.5 h-3.5" />}
            {summary.overallRisk === 'Low' && <CheckCircle2 className="w-3.5 h-3.5" />}
            <span>{summary.overallRisk}</span>
          </div>
          <span className="text-xs text-slate-500 hidden lg:inline">
            ({summary.contractTypeDetected})
          </span>
        </div>

        {/* Metric Badges / Clickable stats */}
        <div className="flex flex-wrap items-center gap-3 sm:gap-6 text-xs text-slate-700">
          <div className="flex items-center gap-1.5">
            <span className="font-mono tabular-nums font-bold text-slate-900 text-sm">
              {summary.totalClauses}
            </span>
            <span className="text-slate-500">clauses analyzed</span>
          </div>

          <span className="text-slate-300 hidden sm:inline" aria-hidden="true">|</span>

          <button
            type="button"
            onClick={() => onFilterFindings && onFilterFindings('all')}
            className={`flex items-center gap-1.5 transition-colors cursor-pointer hover:text-slate-900 ${
              activeFilter === 'all' ? 'font-semibold text-slate-950 underline decoration-slate-900 underline-offset-4' : ''
            }`}
          >
            <span className="font-mono tabular-nums font-bold text-slate-900 text-sm">
              {summary.totalRisks}
            </span>
            <span className="text-slate-600">risks detected</span>
          </button>

          <span className="text-slate-300 hidden sm:inline" aria-hidden="true">|</span>

          <button
            type="button"
            onClick={() => onFilterFindings && onFilterFindings('Contradiction')}
            className={`flex items-center gap-1.5 transition-colors cursor-pointer hover:text-rose-700 ${
              activeFilter === 'Contradiction' ? 'font-semibold text-rose-900 underline decoration-rose-600 underline-offset-4' : ''
            }`}
          >
            <GitCompare className="w-3.5 h-3.5 text-rose-600" />
            <span className="font-mono tabular-nums font-bold text-rose-700 text-sm">
              {summary.contradictionsCount}
            </span>
            <span className="text-slate-600">contradictions</span>
          </button>

          <span className="text-slate-300 hidden sm:inline" aria-hidden="true">|</span>

          <button
            type="button"
            onClick={() => onFilterFindings && onFilterFindings('Missing Clause')}
            className={`flex items-center gap-1.5 transition-colors cursor-pointer hover:text-amber-700 ${
              activeFilter === 'Missing Clause' ? 'font-semibold text-amber-900 underline decoration-amber-600 underline-offset-4' : ''
            }`}
          >
            <FileQuestion className="w-3.5 h-3.5 text-amber-600" />
            <span className="font-mono tabular-nums font-bold text-amber-700 text-sm">
              {summary.missingClausesCount}
            </span>
            <span className="text-slate-600">missing clauses</span>
          </button>

          {summary.jurisdictionIssuesCount > 0 && (
            <>
              <span className="text-slate-300 hidden sm:inline" aria-hidden="true">|</span>
              <button
                type="button"
                onClick={() => onFilterFindings && onFilterFindings('Jurisdiction Conflict')}
                className={`flex items-center gap-1.5 transition-colors cursor-pointer hover:text-blue-700 ${
                  activeFilter === 'Jurisdiction Conflict' ? 'font-semibold text-blue-900 underline decoration-blue-600 underline-offset-4' : ''
                }`}
              >
                <Globe2 className="w-3.5 h-3.5 text-blue-600" />
                <span className="text-blue-700 font-semibold">Jurisdiction review</span>
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
