import React, { useRef, useEffect, useState } from 'react';
import { Clause, RiskFinding } from '../types/contract';
import { Search, ShieldAlert, AlertTriangle, ArrowUpRight, Check, Hash, Filter } from 'lucide-react';

interface ContractReaderProps {
  clauses: Clause[];
  selectedFinding: RiskFinding | null;
  onSelectClause: (clause: Clause) => void;
  onSelectFindingByClauseId: (clauseId: string) => void;
  allFindings: RiskFinding[];
}

export const ContractReader: React.FC<ContractReaderProps> = ({
  clauses,
  selectedFinding,
  onSelectClause,
  onSelectFindingByClauseId,
  allFindings
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const clauseRefs = useRef<Record<string, HTMLDivElement | null>>({});

  // Auto-scroll when selected finding changes
  useEffect(() => {
    if (selectedFinding && selectedFinding.affectedClauseIds.length > 0) {
      const primaryId = selectedFinding.affectedClauseIds[0];
      const el = clauseRefs.current[primaryId];
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }
  }, [selectedFinding]);

  // Map each clause ID to its associated findings
  const clauseFindingsMap = React.useMemo(() => {
    const map = new Map<string, RiskFinding[]>();
    for (const f of allFindings) {
      for (const cid of f.affectedClauseIds) {
        if (!map.has(cid)) map.set(cid, []);
        map.get(cid)!.push(f);
      }
    }
    return map;
  }, [allFindings]);

  // Categories list for filter
  const categories = React.useMemo(() => {
    const set = new Set(clauses.map(c => c.category));
    return Array.from(set).sort();
  }, [clauses]);

  // Filter clauses
  const filteredClauses = clauses.filter(c => {
    const matchesSearch =
      searchQuery === '' ||
      c.clauseNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.text.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory =
      selectedCategory === 'all' || c.category === selectedCategory;

    return matchesSearch && matchesCategory;
  });

  return (
    <div className="flex flex-col h-full bg-white border-r border-slate-200">
      {/* Top Search & Filter Bar */}
      <div className="p-3 border-b border-slate-200 bg-slate-50/70 space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
            <Hash className="w-3.5 h-3.5 text-slate-500" />
            Contract Document ({clauses.length} Clauses)
          </span>
          <span className="text-[11px] text-slate-500">
            Click any clause to inspect
          </span>
        </div>

        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search clause text, title, or section #..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full text-xs pl-8 pr-3 py-1.5 bg-white border border-slate-300 rounded-md focus:outline-hidden focus:ring-1 focus:ring-slate-800 focus:border-slate-800"
            />
          </div>

          <select
            value={selectedCategory}
            onChange={e => setSelectedCategory(e.target.value)}
            className="text-xs py-1.5 px-2 bg-white border border-slate-300 rounded-md text-slate-700 focus:outline-hidden"
          >
            <option value="all">All Categories</option>
            {categories.map(cat => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Clause Stream */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {filteredClauses.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-500">
            No clauses match your search or filter.
          </div>
        ) : (
          filteredClauses.map(clause => {
            const isAffectedBySelected =
              selectedFinding?.affectedClauseIds.includes(clause.id);

            const associatedFindings = clauseFindingsMap.get(clause.id) || [];
            const hasCritical = associatedFindings.some(f => f.severity === 'Critical');
            const hasHigh = associatedFindings.some(f => f.severity === 'High');
            const hasContradiction = associatedFindings.some(f => f.type === 'Contradiction');

            // Find companion conflicting clause if any
            const contraFinding = associatedFindings.find(f => f.type === 'Contradiction');
            const companionClauseId = contraFinding?.affectedClauseIds.find(id => id !== clause.id);
            const companionClause = companionClauseId
              ? clauses.find(c => c.id === companionClauseId)
              : null;

            return (
              <div
                key={clause.id}
                ref={el => { clauseRefs.current[clause.id] = el; }}
                onClick={() => onSelectClause(clause)}
                className={`rounded-lg border transition-all cursor-pointer p-4 ${
                  isAffectedBySelected
                    ? 'border-slate-900 ring-2 ring-slate-900/10 bg-slate-50 shadow-sm'
                    : hasCritical
                    ? 'border-rose-200 bg-rose-50/20 hover:border-rose-300'
                    : hasHigh
                    ? 'border-amber-200 bg-amber-50/20 hover:border-amber-300'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                {/* Header: Number, Title, Category */}
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-mono text-xs font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded-sm">
                      {clause.clauseNumber}
                    </span>
                    <h3 className="text-xs font-semibold text-slate-900">
                      {clause.title}
                    </h3>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <span className="text-[11px] text-slate-500">
                      {clause.category}
                    </span>
                    {clause.pageNumber && (
                      <span className="text-[10px] text-slate-400 font-mono">
                        p.{clause.pageNumber}
                      </span>
                    )}
                  </div>
                </div>

                {/* Contradiction Alert Banner inside Clause */}
                {contraFinding && companionClause && (
                  <div
                    onClick={e => {
                      e.stopPropagation();
                      onSelectFindingByClauseId(clause.id);
                    }}
                    className="mb-2.5 p-2 rounded-md bg-rose-50 border border-rose-200 text-xs text-rose-900 flex items-center justify-between gap-2 hover:bg-rose-100 transition-colors"
                  >
                    <div className="flex items-center gap-1.5 font-medium">
                      <ShieldAlert className="w-3.5 h-3.5 text-rose-700 shrink-0" />
                      <span>
                        Contradicts {companionClause.clauseNumber} ({contraFinding.contradiction?.conflictDimension || 'Direct Conflict'})
                      </span>
                    </div>
                    <span className="text-[11px] underline font-semibold text-rose-700 shrink-0">
                      View Conflict
                    </span>
                  </div>
                )}

                {/* Clause Full Text */}
                <div className="text-xs text-slate-700 leading-relaxed font-sans whitespace-pre-wrap">
                  {clause.text}
                </div>

                {/* Detected key entities badges */}
                {(clause.keyEntities.monetaryValues?.length ||
                  clause.keyEntities.noticePeriods?.length ||
                  clause.keyEntities.durations?.length ||
                  clause.keyEntities.jurisdictions?.length) ? (
                  <div className="mt-3 pt-2 border-t border-slate-100 flex flex-wrap items-center gap-2 text-[11px] text-slate-500">
                    {clause.keyEntities.monetaryValues?.map((m, i) => (
                      <span key={i} className="text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded-xs font-mono">
                        {m}
                      </span>
                    ))}
                    {clause.keyEntities.noticePeriods?.map((n, i) => (
                      <span key={i} className="text-amber-800 bg-amber-50 px-1.5 py-0.5 rounded-xs font-medium">
                        Notice: {n}
                      </span>
                    ))}
                    {clause.keyEntities.durations?.map((d, i) => (
                      <span key={i} className="text-blue-800 bg-blue-50 px-1.5 py-0.5 rounded-xs">
                        Survival: {d}
                      </span>
                    ))}
                    {clause.keyEntities.jurisdictions?.map((j, i) => (
                      <span key={i} className="text-purple-800 bg-purple-50 px-1.5 py-0.5 rounded-xs">
                        Forum: {j}
                      </span>
                    ))}
                  </div>
                ) : null}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
