import React from 'react';
import { ShieldAlert, FileText, Share2, Sparkles, BookOpen } from 'lucide-react';

interface HeaderProps {
  activeView: 'split' | 'map';
  setActiveView: (view: 'split' | 'map') => void;
  onOpenReport: () => void;
  onOpenRules: () => void;
  onLoadDemo: () => void;
  hasAnalysis: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  activeView,
  setActiveView,
  onOpenReport,
  onOpenRules,
  onLoadDemo,
  hasAnalysis
}) => {
  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-xs border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Zone 1: Single text element wordmark */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-md bg-slate-900 flex items-center justify-center text-white">
            <ShieldAlert className="w-4 h-4 text-white" />
          </div>
          <div className="flex flex-col">
            <span className="text-base font-semibold tracking-tight text-slate-900 leading-none">
              ClauseGuard AI
            </span>
            <span className="text-[11px] text-slate-500 font-normal mt-0.5">
              Legal Contract Risk & Contradiction Analyzer
            </span>
          </div>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
          <button
            onClick={() => setActiveView('split')}
            className={`transition-colors text-xs font-medium py-1 ${
              activeView === 'split' ? 'text-slate-950 border-b-2 border-slate-900 font-semibold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Audit Workspace
          </button>
          <button
            onClick={() => setActiveView('map')}
            className={`transition-colors text-xs font-medium py-1 ${
              activeView === 'map' ? 'text-slate-950 border-b-2 border-slate-900 font-semibold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Contract Risk Map
          </button>
          <button
            onClick={onOpenRules}
            className="transition-colors text-xs font-medium py-1 text-slate-600 hover:text-slate-900 flex items-center gap-1.5"
          >
            <BookOpen className="w-3.5 h-3.5 text-slate-400" />
            Safe Ruleset
          </button>
        </nav>

        {/* Zone 3: Primary Actions */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={onLoadDemo}
            className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors whitespace-nowrap flex items-center gap-1.5"
            title="Load built-in contract with deliberate benchmark contradictions"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
            <span className="hidden sm:inline">Load</span> Demo Contract
          </button>

          {hasAnalysis && (
            <button
              onClick={onOpenReport}
              className="px-3.5 py-1.5 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-md transition-colors whitespace-nowrap flex items-center gap-1.5 shadow-xs"
            >
              <FileText className="w-3.5 h-3.5 text-slate-200" />
              Generate Audit Report
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
